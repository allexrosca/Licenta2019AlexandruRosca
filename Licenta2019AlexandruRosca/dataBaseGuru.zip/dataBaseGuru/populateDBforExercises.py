# https://faker.readthedocs.io/en/master/ -> adaptat

import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','dataBaseGuru.settings')

import django
django.setup()

import random
from exercises.models import Crew, Ship, Sailing, Booking, Employee, Assign
from faker import Faker
import datetime

fake = Faker()


def add_ship_n_companies(Nship=5, Ncompanies = 5):
    companies = []
    ships = []
    shipsCapacities = []
    for i in range(0,Ncompanies):
        companies.append(fake.company())
    for i in range(0,Nship):
        capacity = random.randint(20,100)
        ship = Ship.objects.get_or_create(manufacturer = random.choice(companies),
                                          fabrication_series = fake.license_plate(),
                                          ship_capacity = capacity)[0]
        ships.append(ship)
        shipsCapacities.append(capacity)
        ship.save()
    return ships, shipsCapacities



def add_employee(Nemployee = 50):
    employees = []

    rank_title = [
        'captain',
        'sailor',
        'engineer',
        'steward',
    ]

    captainFound = 0
    engineerFound = 0

    for i in range(0,Nemployee):
        rank = random.choice(rank_title)

        if rank == 'captain':
            captainFound = captainFound + 1

        if rank == 'engineer':
            engineerFound = engineerFound + 1

        if captainFound >= 0.07 * Nemployee and captainFound > 0:
            rank_title.remove('captain')
            captainFound = -1

        if engineerFound >= 0.1 * Nemployee and engineerFound > 0:
            rank_title.remove('engineer')
            engineerFound = -1


        employee = Employee.objects.get_or_create(person_id=fake.postalcode(),
                                                first_name=fake.first_name(),
                                                last_name=fake.last_name(),
                                                rank=rank)[0]

        employees.append(employee)
        employee.save()

    return employees


def add_crew(Ncrew=5):
    crews=[]

    for i in range(0,Ncrew):
        crew = Crew.objects.get_or_create(crew_name= fake.profile()['username'].upper(),
                                           raiting=random.randint(0,10))[0]
        crews.append(crew)
        crew.save()
    return crews


def populate(Nship=5, Ncompanies = 5, Nemployee=50, Ncrews=5, Nsailings=5):
    sailings = []

    print('-------ADD SHIPS-----')
    ships, shipsCapacities = add_ship_n_companies(Nship, Ncompanies)
    print('-------FINISHED-----')
    print()

    print('-------ADD EMPLOYEES-----')
    employees = add_employee(Nemployee)
    print('-------FINISHED-----')
    print()

    print('-------ADD CREWS-----')
    crews = add_crew(Ncrews)
    print('-------FINISHED-----')
    print()

    print('-------ASSIGN PEOPLE TO A CREW-----')
    for i in employees:
        assign = Assign.objects.get_or_create(crew_id=random.choice(crews),
                                              employee_id=i)[0]

        assign.save()
    print('-------FINISHED-----')
    print()


    print('-------ADD SAILINGS-------')
    date = fake.date_between(start_date="-15y", end_date='-13y')
    bigDelay = random.randint(50,100)
    randomDelay = random.randint(10,50)
    shipOfSailCapacity = []
    for i in range(0, Nsailings):
        crewAUX = list(crews)
        edate = 0
        for j in range(0, len(ships) - int(random.randint(0, 2))):
            sdate = fake.date_time_between_dates(datetime_start=date, datetime_end=date + datetime.timedelta(days=bigDelay), tzinfo=None)
            sdateDelay = fake.date_time_between_dates(datetime_start=sdate, datetime_end=sdate + datetime.timedelta(days=random.randint(0,3)), tzinfo=None)
            edate = fake.date_time_between_dates(datetime_start=sdateDelay, datetime_end=sdateDelay + datetime.timedelta(days=randomDelay), tzinfo=None)
            crewChoice = random.choice(crewAUX)
            sailing = Sailing.objects.get_or_create(ship_id=ships[j],
                                                    crew_id=crewChoice,
                                                    sail_date=sdate,
                                                    departure=fake.country(),
                                                    destination=fake.country(),
                                                    start_time=random.choice([sdate, sdateDelay]),
                                                    end_time=edate)[0]
            shipOfSailCapacity.append(shipsCapacities[j])
            crewAUX.remove(crewChoice)
            sailings.append(sailing)
            sailing.save()
        startDate = str('-' + str(2019 - int(str(edate)[0:4]) - 1) + "y")
        endDate = str('-' + str(2019 - int(str(edate)[0:4]) - 3) + "y")
        date = fake.date_between(start_date=startDate, end_date=endDate)
        bigDelay = random.randint(50, 100)
        randomDelay = random.randint(10, 50)
    print('------FINISHED------')
    print()



    print('------ADD BOOKINGS-------')
    shipNr = 0
    for i in range(0,len(sailings)):
        for j in range(0,random.randint(0,shipOfSailCapacity[shipNr])):
            booking = Booking.objects.get_or_create(sail_id=sailings[i],
                                                    person_id=fake.bban(),
                                                    first_name=fake.first_name(),
                                                    last_name=fake.last_name())[0]
            booking.save()
        shipNr = shipNr + 1
    print('-------FINISHED--------')
    print()

if __name__ == '__main__':
    print('------------- POPULATION STARTED ----------------')
    print()
    populate()
    print('------------- POPULATION FINISHED ----------------')
