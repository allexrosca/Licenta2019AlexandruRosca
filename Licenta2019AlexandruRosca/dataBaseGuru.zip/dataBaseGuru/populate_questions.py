# https://faker.readthedocs.io/en/master/ -> adaptat

import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dataBaseGuru.settings')

import django

django.setup()

import random
from exercises.models import Exercise, Progress
from accounts.models import UserProfile, Teacher, CustomAdmin, TeacherRequest, AdminRequest, User
from faker import Faker
import datetime
from exercises.views import testQuery

fake = Faker()

allTeachers = UserProfile.objects.filter(is_teacher=True)

teacherCreators = [random.choice(allTeachers) for i in range(0,3)]

questionsList = [('Show all the crew names with the number of how many employees are in them.',
                  "select crew_name, count(*) from assign join crew on crew_id = crew.id join employee on employee_id = employee.id group by crew_id"),
                 ("Select all the sailings from the past 10 years.",
                  "select * from sailing where sail_date > '2009-01-01'"),
                 ("Select the departure as \"DP\" and the destination as \"DT\" of the sailings that had a delay.",
                  "select departure as DP, destination as DT from sailing where sail_date != start_time"),
                 ("Show the manufacturer, the crew_name, the raiting of the crew, the departure and the destination of the sailing that finished the trip in 20 days.",
                  "select manufacturer, crew_name, raiting, departure, destination from sailing join ship on ship_id=ship.id join crew on crew_id=crew.id where julianday(end_time) - julianday(start_time) < 20"),
                 ("Show the id and the number of how many people were aboard at every sailing.",
                  "select s.id, count(*) from sailing s join booking b on b.sail_id=s.id group by s.id"),
                 ("Select all the information available for the last sailing to the Liberia. (use the sail_date)",
                  "select * from sailing where departure like 'Liberia' order by sail_date desc limit 1"),
                 ("Show the first name and the last name of all employees.",
                  "select first_name, last_name from employee"),
                 ("Show the name of the crews for all the sailings with no starting delay.",
                  "select crew_name from sailing join crew on crew_id=crew.id where sail_date = start_time"),
                 ("Show all the information for all the captains.",
                  "select * from employee where rank = 'captain'"),
                 ("Show ship capacity in a column named CAPACITY, for the ships with sailings in 2004.",
                  "select ship_capacity as CAPACITY from ship join sailing on ship.id=ship_id where sail_date > '2004-01-01' and sail_date < '2004-12-31'")]


def populate_questions():
    print('------POPULATING QUESTIONS---------')
    print()
    questions = []
    for i in questionsList:
        question = Exercise.objects.get_or_create(question=i[0],
                                          answer=i[1],
                                          hint='Sorry, this is just a generated question :(',
                                          teacherCreator=Teacher.objects.get(teacher=random.choice(teacherCreators)),
                                          totalColumnsPoints=random.randrange(0,999),
                                          partialColumnsPoints=random.getrandbits(1),
                                          columnPercentage=random.randrange(0,99),
                                          totalEntryPoints=random.randrange(0,999),
                                          partialEntryPoints=random.getrandbits(1),
                                          entryPercentage=random.randrange(0,99),
                                          bonusPoints=random.randrange(0,999))[0]
        question.save()
        questions.append(question)
    print('--------FINISHED----------')
    print()
    return questions

def populate(N=20):
    users = UserProfile.objects.all()
    questions = populate_questions()
    print('--------MAKING PEOPLE TO ANSWER THE QUESTIONS----------')
    print()
    for i in questions:
        totalPoints = i.totalColumnsPoints + i.totalEntryPoints + i.bonusPoints
        for x in range(0,random.randrange(1,N)):
            pointsChoices = [0, random.randrange(0, totalPoints), totalPoints]
            points = random.choice(pointsChoices)
            user = random.choice(users)
            answer = Progress.objects.get_or_create(id_question=i,
                                            id_student=user,
                                            user_answer=fake.text(max_nb_chars=200, ext_word_list=None),
                                            points=points)[0]
            answer.save()
            user.score = user.score + points
            user.save()
    print('--------FINISHED----------')
    print()


if __name__ == '__main__':
    print('------------- POPULATION STARTED ----------------')
    print()
    populate()
    print('------------- POPULATION FINISHED ----------------')
