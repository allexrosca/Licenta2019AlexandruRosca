from django.apps import AppConfig


class ExtrahelpConfig(AppConfig):
    name = 'extraHelp'
