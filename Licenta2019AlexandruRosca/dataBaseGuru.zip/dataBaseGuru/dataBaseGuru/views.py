# https://docs.djangoproject.com/en/2.2/topics/auth/default/#django.contrib.auth.mixins.AccessMixin -> adaptat
# https://stackoverflow.com/questions/2320581/django-redirect-logged-in-users-from-login-page -> adaptat
from django.views.generic import View, TemplateView
from django.contrib.auth.mixins import UserPassesTestMixin
from dataBaseGuru import settings
from django.shortcuts import redirect
from exercises.views import testQuery, get_models_info
from django.views.generic import DetailView, ListView
from exercises import models as exercises_models
from django.http import JsonResponse




class HomePageView(UserPassesTestMixin, TemplateView):
    template_name = 'dataBaseGuru/homePage.html'

    def dispatch(self, *args, **kwargs):
        if self.request.user.is_authenticated:
            return redirect(settings.LOGIN_REDIRECT_URL)
        return super().dispatch(*args, **kwargs)

    def test_func(self):
        return redirect('dataBaseGuru/homePage.html')


class GuestExerciseList(ListView):
    template_name = 'dataBaseGuru/guest_exercise_list.html'
    model = exercises_models.Exercise
    context_object_name = 'exercises'

    def get_queryset(self):
        queryset = exercises_models.Exercise.objects.all()
        return queryset[:3]


class GuestExercise(DetailView):
    template_name = 'dataBaseGuru/guest_exercise.html'
    model = exercises_models.Exercise
    context_object_name = 'exercise'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['dbTables'] = get_models_info()

        ids = []
        allQuestions = exercises_models.Exercise.objects.all()
        availableQuestions = allQuestions[:3]
        for i in availableQuestions:
            ids.append(i.id)

        currentQuestion = self.kwargs.get('pk')
        nextQuestion = -1
        found = 0
        for i in ids:
            if i == currentQuestion:
                found = 1
                continue
            if found == 1:
                nextQuestion = i
                break

        if found == 1 and nextQuestion == -1:
            nextQuestion = ids[0]

        context['nextQuestion'] = nextQuestion

        return context


def previewSolution(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect(reverse('exercise:exercises_index'))

    context = dict()

    columns, info, queryResDict, errors = testQuery(request.GET.get('userQuery'))

    context['columns'] = columns
    context['info'] = info
    context['userQueryError'] = errors

    return JsonResponse(context)


