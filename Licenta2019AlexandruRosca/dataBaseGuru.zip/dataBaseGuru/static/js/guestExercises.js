// https://stackoverflow.com/questions/11921450/body-onclick-anything-function -> adaptat
$(document).on('click','body *',function(){
        $('html, body').css("overflow","visible");
// ################
});



$(document).ready(
    $('#preview').on("click",function(){
        let userQuery = $("#userQuery").val();
        let pk = $("#preview").attr("data-pk");

        $.ajax({
            url: '/previewSolution/',
            data: {
                'userQuery': userQuery,
                'pk': pk
            },
            dataType: 'json',
            success: function(e) {
                $('#userQueryOutput').empty();
                if(e['userQueryError'] != ''){
                    $('#table-spot').addClass("animated shake delay-1s");
                    $('#greenArrow').addClass("animated rubberBand ");
                    setTimeout(function(){
                        $('#userQueryOutput').empty();
                        let content = '<tr><th scope=\"col\" class=\"text-orange\">';
                        content = content + e['userQueryError'] + '</th></tr>';
                        $('#userQueryOutput').append(content);
                    },1000);
                }
                else{
                    $('#allCont').css("overflow","hidden");
                    $('#greenArrow').addClass("animated rubberBand ");
                    $('#table-spot').addClass("animated heartBeat delay-1s");

                    setTimeout(function(){
                        let content;
                        let i;
                        let j;
                        let k;
                        content = content + '<thead><tr>';
                        for (i = 0; i < e['columns'].length; i++) {
                            content += '<th scope=\"col\" class=\"text-green\">' + e['columns'][i] + '</th>';
                        }
                        content = content + '</tr></thead><tbody>';

                        for (j = 0; j < e['info'].length; j++){
                            content = content + '<tr>';
                            for(k = 0; k < e['columns'].length; k++){
                                if(k===0){
                                    content = content + '<th scope=\"row\">' + e['info'][j][k]  + '</th>';
                                }
                                else{
                                    content = content + '<td>' + e['info'][j][k]  + '</td>';
                                }
                            }
                            content = content + '</tr>';
                        }
                        content = content + '</tbody>';

                        $('#userQueryOutput').append(content);
                    },1000);

                }
                 setTimeout(function(){
                   $("#greenArrow").removeClass("animated rubberBand");
                   $("#table-spot").removeClass("animated shake delay-1s");
                   $('#table-spot').removeClass("animated heartBeat delay-1s");
                 }, 2000);


            }
        })
    }),


    $('.customhid').on("click",function(){
        let tableItemsId = $(this).attr("data-id");

        $(".tableItems").each(function() {
            if(!$(this).attr("d-none"))
                $(this).addClass('d-none');
        });
        $(".customhid").each(function() {
            $(this).removeClass("btn-orange").addClass("btn-outline-green")
        });

        $('#'+tableItemsId).removeClass("d-none");
        $(this).removeClass("btn-outline-green").addClass("btn-orange")


    })
);

$("i").tooltip({
    'selector': '',
    'placement': 'bottom',
    'container': 'body'
});