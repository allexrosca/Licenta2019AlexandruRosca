from django.urls import path
from django.contrib.auth import views as auth_views
from exercises import views as exercises_views
app_name = 'exercises'

urlpatterns =[
    path('index/', exercises_views.ExerciseList.as_view(), name='exercises_index'),
    path('exercise/<int:pk>/', exercises_views.Exercise.as_view(), name='exercise'),
    path('previewSolution/', exercises_views.previewSolution, name='previewSolution'),
    path('submitSolution/', exercises_views.submitSolution, name='submitSolution'),
    path('submitQuestion/', exercises_views.submitQuestion, name='submit_exercise'),
    path('manageQuestions/', exercises_views.ManageQuestions.as_view(), name='manageQuestions'),
    path('manageQuestions/<int:id>/delete', exercises_views.question_delete, name='question_delete'),
    path('history/', exercises_views.History.as_view(), name='history'),
    path('seeExercise/<int:pk>/', exercises_views.SeeExercise.as_view(), name='seeExercise'),
    path('statisticsHome/<int:pk>-<int:id>/', exercises_views.StatisticsHome.as_view(), name='statisticsHome'),
    path('statistics/<int:pk>/', exercises_views.Statistics.as_view(), name='statistics'),
    path('allQuestionsStatistics/<int:pk>/', exercises_views.AllQuestionsStatistics.as_view(), name='allQuestionsStatistics'),
    path('statisticsForAllQuestions/<int:pk>/', exercises_views.StatisticsForAllQuestions.as_view(), name='statisticsForAllQuestions'),

]