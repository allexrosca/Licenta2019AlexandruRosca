from django.contrib import admin
# from exercises.models import Exercise, Course, Student, Grade, TeacherInfo, Assignment, Progress
from exercises.models import Ship, Booking, Crew, Employee, Exercise, Sailing, Progress

# Register your models here.
# admin.site.register(Exercise)
# admin.site.register(Course)
# admin.site.register(Student)
# admin.site.register(Grade)
# admin.site.register(TeacherInfo)
# admin.site.register(Assignment)
# admin.site.register(Progress)


admin.site.register(Exercise)
admin.site.register(Progress)
admin.site.register(Sailing)
admin.site.register(Ship)
admin.site.register(Booking)
admin.site.register(Crew)
admin.site.register(Employee)
