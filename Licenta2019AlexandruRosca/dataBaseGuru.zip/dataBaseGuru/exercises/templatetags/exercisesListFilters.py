# https://docs.djangoproject.com/en/2.2/howto/custom-template-tags/
from django import template
register = template.Library()

from exercises import models as exercises_models
from accounts import models as accounts_models


@register.filter(name='answered')
def answered(value, uId):
    try:
        question = exercises_models.Exercise.objects.get(id=value)
        answrd = exercises_models.Progress.objects.get(id_question = question,id_student = uId)
        if answrd:
            answrd = True
        else:
            answrd = False
    except:
        answrd = False

    value = answrd
    return value


@register.filter(name='points')
def points(value, uId):
    try:
        question = exercises_models.Exercise.objects.get(id=value)
        answrd = exercises_models.Progress.objects.get(id_question = question, id_student = uId)
        points = answrd.points
    except:
        points = 0

    value = points

    return value


@register.filter(name='totalAnswered')
def totalAnswered(value):
    try:
        progress = exercises_models.Progress.objects.filter(id_question= value).count()
    except:
        progress = 0

    value = progress

    return value

@register.filter(name='bestAnswered')
def bestAnswered(value):
    exercise = exercises_models.Exercise.objects.get(id=value)
    totalPoints = exercise.totalEntryPoints + exercise.totalColumnsPoints + exercise.bonusPoints
    progress = exercises_models.Progress.objects.filter(id_question= value).filter(points=totalPoints).count()

    value = progress

    return value


@register.filter(name='totalPoints')
def totalPoints(value):
    exercise = exercises_models.Exercise.objects.get(id=value)
    value = exercise.totalColumnsPoints + exercise.totalEntryPoints + exercise.bonusPoints
    return value


@register.filter(name='userAnswer')
def userAnswer(value, userpk):
    userProfile = accounts_models.UserProfile.objects.get(id=userpk)
    exercise = exercises_models.Exercise.objects.get(id=value)
    try:
        progress = exercises_models.Progress.objects.get(id_question= exercise, id_student=userProfile)
    except:
        progress = False

    if progress:
        value = progress.user_answer
    return value


@register.filter(name='teacherAnswer')
def teacherAnswer(value):
    exercise = exercises_models.Exercise.objects.get(id=value)
    value = exercise.answer
    return value

