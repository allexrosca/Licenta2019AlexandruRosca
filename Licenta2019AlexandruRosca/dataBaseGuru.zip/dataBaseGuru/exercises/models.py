from django.db import models
from accounts import models as accounts_models
from django.db.models.signals import pre_delete
from django.dispatch import receiver
from django.core.validators import MaxValueValidator


# Create your models here.
class Exercise(models.Model):
    BOOL_CHOICE = (
        (True, 'Yes'),
        (False, 'No')
    )

    question = models.TextField(max_length=255)
    answer = models.TextField(max_length=1000)
    hint = models.TextField(max_length=255, blank=True, default='')
    teacherCreator = models.ForeignKey(accounts_models.Teacher, null=False, db_column='teacherCreator', on_delete=models.CASCADE)

    totalColumnsPoints =  models.DecimalField(max_digits=19, decimal_places=2, default=25)
    partialColumnsPoints = models.BooleanField(choices= BOOL_CHOICE, default=True)
    columnPercentage = models.PositiveIntegerField(default= 1, blank=True, null= True)

    totalEntryPoints = models.DecimalField(max_digits=19, decimal_places=2, default=75)
    partialEntryPoints = models.BooleanField(choices= BOOL_CHOICE, default=True)
    entryPercentage = models.PositiveIntegerField(default= 1, blank=True, null= True)

    bonusPoints = models.DecimalField(max_digits=19, decimal_places=2, default=50)


    def __str__(self):
        return self.question


class Progress(models.Model):
    id_question = models.ForeignKey(Exercise, null=False,db_column='id_question', on_delete=models.CASCADE)
    id_student = models.ForeignKey(accounts_models.UserProfile, null=False, db_column='id_student', on_delete=models.CASCADE)
    user_answer = models.CharField(max_length=2000,null=False)
    points = models.DecimalField(max_digits=19, decimal_places=2, null=False, default=0)

    def __str__(self):
      return (f'{self.id_question}, {self.id_student}, {self.points}')


@receiver(pre_delete, sender=Exercise)
def log_deleted_question(sender, instance, using, **kwargs):
    try:
        prg = Progress.objects.filter(id_question=instance.id)
        for i in prg:
            try:
                userProfile = accounts_models.UserProfile.objects.get(id = i.id_student.id)
            except Exception as e:
                userProfile = False
                print(e)

            if userProfile:
                userProfile.score = userProfile.score - i.points
                userProfile.save()

    except Exception as e:
        print(e)


class Ship(models.Model):
    manufacturer = models.CharField(max_length=20, null=False, blank=False)
    fabrication_series = models.CharField(max_length=20, null=False, blank=False)
    ship_capacity = models.PositiveIntegerField(null=False, blank=False)

    class Meta:
        db_table = 'ship'

    def __str__(self):
        return str(f'{self.manufacturer}, {self.fabrication_series}, {self.ship_capacity}')


class Employee(models.Model):
    RANK_TYPES = (
        ('captain', 'captain'),
        ('sailor', 'sailor'),
        ('engineer','engineer'),
        ('steward','steward'),
    )
    person_id = models.CharField(max_length=10, blank=False, null=False)
    first_name = models.CharField(max_length=20, blank=False, null=False)
    last_name = models.CharField(max_length=20, blank=False, null=False)
    rank = models.CharField(choices= RANK_TYPES, max_length=8, blank=False, null=False)

    class Meta:
        db_table = 'employee'

    def __str__(self):
        return str(f'{self.first_name}, {self.last_name}, {self.rank}')


class Crew(models.Model):
    crew_name = models.CharField(null=False, blank=False, max_length=20)
    raiting = models.PositiveIntegerField(null=False, blank=False, validators=[MaxValueValidator(10)])

    class Meta:
        db_table = 'crew'

    def __str__(self):
        return str(f'{self.crew_name}, {self.raiting}')


class Assign(models.Model):
    crew_id = models.ForeignKey(Crew, null=False, db_column='crew_id', on_delete=models.CASCADE)
    employee_id = models.ForeignKey(Employee, null=False, db_column='employee_id', on_delete=models.CASCADE)

    class Meta:
        db_table='assign'

    def __str__(self):
        return str(f'{self.crew_id},{self.employee_id}')


class Sailing(models.Model):
    ship_id = models.ForeignKey(Ship, null=False, db_column='ship_id', on_delete=models.CASCADE)
    crew_id = models.ForeignKey(Crew, null=False, db_column='crew_id', on_delete=models.CASCADE)
    sail_date = models.DateField(null=False, blank=False)
    departure = models.CharField(max_length=20, null=False, blank=False)
    destination = models.CharField(max_length=20, null=False, blank=False)
    start_time = models.DateField(null=False, blank=False)
    end_time = models.DateField(null=False, blank=False)

    class Meta:
        db_table = 'sailing'

    def __str__(self):
        return str(f'{self.departure}, {self.destination}, {self.sail_date}')



class Booking(models.Model):
    sail_id = models.ForeignKey(Sailing, db_column='sail_id', on_delete=models.CASCADE)
    person_id = models.CharField(max_length=10, blank=False, null=False)
    first_name = models.CharField(max_length=20, blank=False, null=False)
    last_name = models.CharField(max_length=20, blank=False, null=False)

    class Meta:
        db_table = 'Booking'

    def __str__(self):
        return str(f'{self.first_name}, {self.last_name}')