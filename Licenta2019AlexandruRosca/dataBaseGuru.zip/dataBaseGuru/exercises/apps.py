from django.apps import AppConfig


class ExercisesConfig(AppConfig):
    name = 'exercises'
