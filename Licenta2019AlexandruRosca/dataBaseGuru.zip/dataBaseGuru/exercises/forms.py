from django import forms
from exercises.models import Exercise


class SubmitQuestionForm(forms.ModelForm):
    class Meta():
        model = Exercise
        exclude = ('teacherCreator',)

    def __init__(self, *args, **kwargs):
        super(SubmitQuestionForm, self).__init__(*args, **kwargs)
        self.fields['question'].widget.attrs.update({'placeholder': 'Write your question here: '})
        self.fields['question'].widget.attrs.update({'rows': '1'})

        self.fields['hint'].widget.attrs.update({'placeholder': 'Give a hint! (if you want to)'})
        self.fields['hint'].widget.attrs.update({'rows': '1'})

        self.fields['answer'].widget.attrs.update({'rows': '3'})
        self.fields['answer'].widget.attrs.update({'placeholder': 'Write your answer here: '})

        self.fields['totalColumnsPoints'].label = 'Total Columns Points'

        self.fields['partialColumnsPoints'].label = 'Partial Columns Points'

        self.fields['columnPercentage'].label = 'Column Percentage'
        self.fields['columnPercentage'].widget.attrs.update({'step': '0.01'})

        self.fields['totalEntryPoints'].label = 'Total Entry Points'
        self.fields['totalEntryPoints'].widget.attrs.update({'step': '0.01'})

        self.fields['partialEntryPoints'].label = 'Partial Entry Points'

        self.fields['entryPercentage'].label = 'Entry Percentage'
        self.fields['entryPercentage'].widget.attrs.update({'step': '0.01'})

        self.fields['bonusPoints'].label = 'Bonus Points'
        self.fields['bonusPoints'].widget.attrs.update({'step': '0.01'})
