// https://github.com/mhadiahmed/CRUD-System?fbclid=IwAR2p07Hq2NHoe-53iP-Olr38oOY1i78dqa9o8U2jKyb8jlbtlvCsRXul_eQ -> preluat si adaptat
// teacher
$(document).ready(function(){
	var ShowForm = function(){
		var btn = $(this);
		$.ajax({
			url: btn.attr("data-url"),
			type: 'get',
			dataType:'json',
			beforeSend: function(){
				$('#modal-req').modal('show');
			},
			success: function(data){
				$('#modal-req .modal-content').html(data.html_form);
			}
		});
	};

	var SaveForm =  function(){
		var form = $(this);
		$.ajax({
			url: form.attr('data-url'),
			data: form.serialize(),
			type: form.attr('method'),
			dataType: 'json',
			success: function(data){
				if(data.form_is_valid){
					$('#req-items').html(data.manageQuestions);
					$('#modal-req').modal('hide');
				} else {
					$('#modal-req .modal-content').html(data.html_form)
				}
			}
		})
		return false;
	}

$('#req-items').on("click",".show-form-delete",ShowForm);
$('#modal-req').on("submit",".delete-form",SaveForm)
});

//####################

$("i").tooltip({
    'selector': '',
    'placement': 'left',
    'container': 'body'
});

$("a").tooltip({
    'selector': '',
    'placement': 'bottom',
    'container': 'body'
});



