// https://stackoverflow.com/questions/11921450/body-onclick-anything-function -> adaptat
$(document).on('click','body *',function(){
        $('html, body').css("overflow","visible");
// ################
});



$(document).ready(
    $('#preview').on("click",function(){
        $('#preview').prop('disabled', true);
        setTimeout(function(){
            $('#preview').prop('disabled', false);
        },1500);

        let userQuery = $("#userQuery").val();
        let pk = $("#preview").attr("data-pk");

        $.ajax({
            url: '/exercises/previewSolution/',
            data: {
                'userQuery': userQuery,
                'pk': pk
            },
            dataType: 'json',
            success: function(e) {
                $('#userQueryOutput').empty();
                if(e['userQueryError'] != ''){
                    $('#table-spot').addClass("animated shake delay-1s");
                    $('#greenArrow').addClass("animated rubberBand ");
                    setTimeout(function(){
                        $('#userQueryOutput').empty();
                        let content = '';
                        $.each(e['userQueryError'], function(index, value){
                            content = content + '<tr><th scope=\"col\" class=\"text-orange\">' + Number(Number(index) + 1) + '. ' + value + '</th></tr>';
                        });
                        $('#userQueryOutput').append(content);
                    },1000);
                }
                else{
                    $('#allCont').css("overflow","hidden");
                    $('#greenArrow').addClass("animated rubberBand ");
                    $('#table-spot').addClass("animated heartBeat delay-1s");

                    setTimeout(function(){
                        let content;
                        let i;
                        let j;
                        let k;
                        content = content + '<thead><tr>';
                        for (i = 0; i < e['columns'].length; i++) {
                            content += '<th scope=\"col\" class=\"text-green\">' + e['columns'][i] + '</th>';
                        }
                        content = content + '</tr></thead><tbody>';

                        for (j = 0; j < e['info'].length; j++){
                            content = content + '<tr>';
                            for(k = 0; k < e['columns'].length; k++){
                                if(k===0){
                                    content = content + '<th scope=\"row\">' + e['info'][j][k]  + '</th>';
                                }
                                else{
                                    content = content + '<td>' + e['info'][j][k]  + '</td>';
                                }
                            }
                            content = content + '</tr>';
                        }
                        content = content + '</tbody>';

                        $('#userQueryOutput').append(content);
                    },1000);

                }
                 setTimeout(function(){
                   $("#greenArrow").removeClass("animated rubberBand");
                   $("#table-spot").removeClass("animated shake delay-1s");
                   $('#table-spot').removeClass("animated heartBeat delay-1s");
                 }, 2000);
            }
        })
    }),


    $('#submitBtn').on("click",function(){
        $('#submitBtn').prop('disabled', true);
        setTimeout(function(){
            $('#submitBtn').prop('disabled', false);
        },2000);

        let userQuery = $("#userQuery").val();
        let pk = $("#submitBtn").attr("data-pk");

        $.ajax({
            url: '/exercises/submitSolution/',
            data: {
                'userQuery': userQuery,
                'pk': pk
            },
            dataType: 'json',
            success: function(e) {
                if(e['questionAnswered'] == 1){
                    if(e['nextQuestion'] != "-1"){
                        let nextPk = Number(e['nextQuestion']);
                        $('#submitBtn').removeClass("animated flipInX delay-1s");
                        $('#preview').removeClass("btn-outline-green animated flipInX delay-1s");
                        $('#submitBtn').addClass("animated flipOutX delay-1");
                        $('#preview').addClass("btn-outline-grey animated flipOutX delay-1");

                        setTimeout(function(){
                            $('#submitBtn').after('<a href="http://127.0.0.1:8000/exercises/exercise/' + nextPk + '"/ class="btn btn-outline-orange btn-block animated flipInX" id="nextBtn">Next</a>')
                            $('#submitBtn').remove();
                            $('#divExc').remove();
                            $('#divPrev').remove();

                        },1000);
                    }
                    else{
                        $('#submitBtn').removeClass("animated flipInX delay-1s");
                        $('#preview').removeClass("btn-outline-green animated flipInX delay-1s");
                        $('#submitBtn').addClass("animated flipOutX delay-1");
                        $('#preview').addClass("btn-outline-grey animated flipOutX delay-1");

                        setTimeout(function(){
                            $('#submitBtn').after('<button class="btn btn-outline-grey btn-block animated flipInX" id="nextBtn" title="No exercises available" disabled>Next</button>');
                            $('#submitBtn').remove();
                            $('#divExc').remove();
                            $('#divPrev').remove();

                        },1000);
                    }
                }
                $('#userQueryOutput').empty();
                if(e['userQueryError'] != ''){
                    $('#table-spot').addClass("animated shake delay-1s");
                    $('#greenArrow').addClass("animated rubberBand ");
                    setTimeout(function(){
                        $('#userQueryOutput').empty();
                        let content = '';
                        $.each(e['userQueryError'], function(index, value){
                            content = content + '<tr><th scope=\"col\" class=\"text-orange\">' + Number(Number(index) + 1) + '. ' + value + '</th></tr>';
                        });
                        $('#userQueryOutput').append(content);
                    },1000);

                    if(String(e['userQueryError']).search('Drop') != -1){
                        $('html, body').css("overflow","hidden");
                        $('#userQuery').addClass("animated hinge slow delay-1s");

                        setTimeout(function(){
                            $('#submitBtn').removeClass("animated flipInX delay-1s");
                            $('#preview').removeClass("animated flipInX delay-1s");
                            $('#submitBtn').addClass("animated zoomOut slower");
                            $('#preview').addClass("animated zoomOut slower");
                            setTimeout(function(){
                                $('#userQuery').addClass("d-none");
                                $('#submitBtn').remove();
                                $('#preview').remove();
                            }, 1000);

                            $('#excRedBtn').removeClass("d-none");
                            $('#excRedBtn').addClass("animated zoomIn delay-1s");
                        }, 1000);
                    }
                }
                else{
                    $('html')
                    $('#greenArrow').addClass("animated rubberBand ");
                    $('#table-spot').addClass("animated heartBeat delay-1s");
                    setTimeout(function(){
                        let content;
                        let i;
                        let j;
                        let k;
                    content = content + '<thead><tr>';
                        for (i = 0; i < e['columns'].length; i++) {
                            content += '<th scope=\"col\" class=\"text-green\">' + e['columns'][i] + '</th>';
                        }
                    content = content + '</tr></thead><tbody>';

                        for (j = 0; j < e['info'].length; j++){
                            content = content + '<tr>';
                            for(k = 0; k < e['columns'].length; k++){
                                if(k===0){
                                    content = content + '<th scope=\"row\">' + e['info'][j][k]  + '</th>';
                                }
                                else{
                                    content = content + '<td>' + e['info'][j][k]  + '</td>';
                                }
                            }
                            content = content + '</tr>';
                        }
                        content = content + '</tbody>';
                        $('#userQueryOutput').append(content);

                        $('.card').css("overflow","hidden");
                        $('#allCont').css("overflow","hidden");
                        $('.inCardContent').addClass("animated fadeOut fast");
                        $('#cardContent').addClass("d-flex justify-content-center");
                        setTimeout(function(){
                            $('#cardContent').empty();
                            $('#cardContent').append("<h1 class='text-orange animated zoomIn text-center' id='points'>Points: " + e['points'] +"</h1>");
                            $('#cardContent').append("<h1 class='text-orange animated zoomInUp slow text-center' id='totalScore'>Total Score: " + e['totalScore'] +"</h1>");
                            setTimeout(function(){
                                $('#points').removeClass("animated zoomIn")
                                $('#points').addClass("animated tada")
                            }, 700);
                        }, 850);

                        setTimeout(function(){
                            $('#table-spot').removeClass("heartBeat delay-1s");
                            window.setInterval(function(){
                                $('#table-spot').removeClass("animated bounce");
                                setTimeout(function(){
                                    $('#table-spot').addClass("animated bounce");
                                },3000)
                            }, 3000);
                        },3000);
                    },1000);
                }
                setTimeout(function(){
                    $("#greenArrow").removeClass("animated rubberBand");
                    $("#table-spot").removeClass("animated shake delay-1s");
                    $('#table-spot').removeClass("animated heartBeat delay-1s");
                }, 2000);
            }
        })
    }),


    $('.customhid').on("click",function(){
        let tableItemsId = $(this).attr("data-id");

        $(".tableItems").each(function() {
            if(!$(this).attr("d-none"))
                $(this).addClass('d-none');
        });
        $(".customhid").each(function() {
            $(this).removeClass("btn-orange").addClass("btn-outline-green")
        });

        $('#'+tableItemsId).removeClass("d-none");
        $(this).removeClass("btn-outline-green").addClass("btn-orange")
    }),

    $('#excRedBtn').on("click", function(){
        event.preventDefault();
        $('#allCont').addClass("animated zoomOut slow");
        setTimeout(function(){
            window.location.href = "http://127.0.0.1:8000/exercises/index/";
        }, 1000);
    })
);

$("i").tooltip({
    'selector': '',
    'placement': 'bottom',
    'container': 'body'
});