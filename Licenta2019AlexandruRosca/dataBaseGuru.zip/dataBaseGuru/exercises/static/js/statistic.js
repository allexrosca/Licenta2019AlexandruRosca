// https://www.chartjs.org/docs/latest/getting-started/usage.html -> adaptare
// https://www.youtube.com/watch?v=B4Vmm3yZPgc&t=1315s -> tutorial

$(document).ready(function() {

    var questionPk = $("#container").attr("question-pk");
    var endpoint = 'http://127.0.0.1:8000/exercises/statistics/' + questionPk +'/';
    var defaultData= [];
    var labels = [];

    $.ajax({
        method: 'GET',
        url: endpoint,
        success: function (data) {
            labels=data.labels;
                        console.log(labels);

            defaultData = data.default;
            var ctx = document.getElementById('myChart');
            var myChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: labels,
                    datasets: [{
                        label: '',
                        data: defaultData,
                        backgroundColor: [
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(255, 99, 132, 0.2)'
                        ],
                        borderColor: [
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 99, 132, 1)'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    },

                }
            });



        },
        error: function (error_data) {
            console.log("error");
            console.log(error_data)
        }
    });
})

$("i").tooltip({
    'selector': '',
    'placement': 'bottom',
    'container': 'body'
});