$(document).ready(
    setTimeout(function(){
        $('html, body').css("overflow","visible");
    }, 600),


    $('#preview').on("click",function(){
        $('#preview').prop('disabled', true);
        setTimeout(function(){
            $('#preview').prop('disabled', false);
        },1500);

        let userQuery = $("#id_answer").val();
        let pk = $("#preview").attr("data-pk");
        $('#preview').removeClass("animated flipInX delay-1s");
        $('#preview').removeClass("animated rubberBand");
        setTimeout(function(){
            $('#preview').removeClass("btn-outline-yellow");
            $('#preview').addClass("btn-outline-green");
        },300);

        $.ajax({
            url: '/exercises/previewSolution/',
            data: {
                'userQuery': userQuery,
                'pk': pk
            },
            dataType: 'json',
            success: function(e) {
                $('#userQueryOutput').empty();
                $('#submitBtn').attr("disabled","true");
                if(e['userQueryError'] != ''){
                    $('#submitBtn').attr("disabled","true");
                    $('#table-spot').addClass("animated shake");
                    $('#userQueryOutput').empty();
                    let content = '';
                    $.each(e['userQueryError'], function(index, value){
                        content = content + '<tr><th scope=\"col\" class=\"text-orange\">' + index + '. ' + value + '</th></tr>';
                    });
                    $('#userQueryOutput').append(content);
                }
                else{
                    $('#allCont').css("overflow","hidden");
                    $('#table-spot').addClass("animated heartBeat");

                    let content;
                    let i;
                    let j;
                    let k;
                    content = content + '<thead><tr>';
                    for (i = 0; i < e['columns'].length; i++) {
                        content += '<th scope=\"col\" class=\"text-green\">' + e['columns'][i] + '</th>';
                    }
                    content = content + '</tr></thead><tbody>';

                    for (j = 0; j < e['info'].length; j++){
                        content = content + '<tr>';
                        for(k = 0; k < e['columns'].length; k++){
                            if(k===0){
                                content = content + '<th scope=\"row\">' + e['info'][j][k]  + '</th>';
                            }
                            else{
                                content = content + '<td>' + e['info'][j][k]  + '</td>';
                            }
                        }
                        content = content + '</tr>';
                    }
                    content = content + '</tbody>';

                    $('#userQueryOutput').append(content);

                    $('#submitBtn').removeAttr("disabled");
                    $('#id_question').removeClass("animated shake");
                    $('#id_question').css("border","1px solid var(--green)");

                }
                 setTimeout(function(){
                   $("#table-spot").removeClass("animated shake");
                   $('#table-spot').removeClass("animated heartBeat");
                   $('#preview').removeClass("animated flipInX");
                   $('#submitBtn').removeClass("animated flipInX");
                 }, 1000);


            }
        })
    }),



    $('.customhid').on("click",function(){
        let tableItemsId = $(this).attr("data-id");

        $(".tableItems").each(function() {
            if(!$(this).attr("d-none"))
                $(this).addClass('d-none');
        });
        $(".customhid").each(function() {
            $(this).removeClass("btn-orange").addClass("btn-outline-green")
        });

        $('#'+tableItemsId).removeClass("d-none");
        $(this).removeClass("btn-outline-green").addClass("btn-orange")
    }),


    $('#submitBtn').on("click",function(e){
        if (!($.trim($('#id_question').val()))) {
            $('#id_question').addClass("animated shake");
            $('#submitBtn').attr("disabled","true");
            $('#id_question').css("border","2px solid var(--orange)");
            setTimeout(function(){
                $('#preview').addClass("animated rubberBand");
                setTimeout(function(){
                    $('#preview').removeClass("btn-outline-green");
                    $('#preview').addClass("btn-outline-yellow");
                }, 200);
            }, 1000);
        }
    }),

//https://stackoverflow.com/questions/8828027/how-do-i-delay-a-form-from-submitting -> adaptat
    $('form').submit( function(e) {
        var formId = this.id,
            form = this;
        $('#allCont').addClass("animated fadeOut faster");
        $('html, body').css("overflow","hidden");

        e.preventDefault();

        setTimeout( function () {
            form.submit();
        }, 400);
    }),
//###########################################


//https://stackoverflow.com/questions/39064365/jquery-disable-inputs-when-option-is-selected -> adaptat
    $(function() {
        $("select#id_partialEntryPoints.form-control").on("change",function() {
            $(".entryOpt").prop('disabled',this.value=="False");
        }).change(); // execute on load
    }),

    $(function() {
        $("select#id_partialColumnsPoints.form-control").on("change",function() {
            $(".columnOpt").prop('disabled',this.value=="False");
        }).change(); // execute on load
    }),
//    #####################
);

$("i").tooltip({
	'selector': '',
	'placement': 'right',
	'container':'body'
});