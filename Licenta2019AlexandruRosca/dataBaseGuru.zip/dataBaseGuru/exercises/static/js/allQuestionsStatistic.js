// https://www.chartjs.org/docs/latest/getting-started/usage.html -> adaptare
// https://www.youtube.com/watch?v=B4Vmm3yZPgc&t=1315s -> tutorial

$(document).ready(function() {

    var questionPk = $("#container").attr("teacher-pk");
    var endpoint = 'http://127.0.0.1:8000/exercises/statisticsForAllQuestions/' + questionPk +'/';
    var defaultData= [];
    var labels = [];

    $.ajax({
        method: 'GET',
        url: endpoint,
        success: function (data) {
            labels=data.labels;
            defaultData = data.default;
            bgColor = data.bgColor;
            bdColor = data.bdColor;
            var ctx = document.getElementById('myChart');
            var myChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Answers',
                        data: defaultData,
                        backgroundColor: bgColor,
                        borderColor: bdColor,
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    },

                }
            });

            labels2=data.labels2;
            defaultData2 = data.default2;
            bgColor2 = data.bgColor2;
            bdColor2 = data.bdColor2;
            var ctx2 = document.getElementById('myChart2');
            var myChart2 = new Chart(ctx2, {
                type: 'bar',
                data: {
                    labels: labels2,
                    datasets: [{
                        label: 'Good Answers',
                        data: defaultData2,
                        backgroundColor: bgColor2,
                        borderColor: bdColor2,
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    }

                }
            });


            labels3=data.labels3;
            defaultData3 = data.default3;
            bgColor3 = data.bgColor3;
            bdColor3 = data.bdColor3;
            var ctx3 = document.getElementById('myChart3');
            var myChart3 = new Chart(ctx3, {
                type: 'bar',
                data: {
                    labels: labels3,
                    datasets: [{
                        label: 'Wrong Answers',
                        data: defaultData3,
                        backgroundColor: bgColor3,
                        borderColor: bdColor3,
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    }

                }
            });
        },
        error: function (error_data) {
            console.log("error");
            console.log(error_data)
        }
    });
})

$("i").tooltip({
    'selector': '',
    'placement': 'bottom',
    'container': 'body'
});