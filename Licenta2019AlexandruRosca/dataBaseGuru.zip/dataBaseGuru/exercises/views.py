#https://stackoverflow.com/questions/1995615/how-can-i-format-a-decimal-to-always-show-2-decimal-places -> preluat

from django.contrib.auth.mixins import LoginRequiredMixin
from exercises import models
from accounts import models as accounts_models
from django.views.generic import View, TemplateView, ListView, DetailView
from django.core.exceptions import ObjectDoesNotExist
from django.http import JsonResponse
from django.db import connection
import xml.etree.ElementTree as et
from django.http import HttpResponseRedirect, HttpResponse
from decimal import Decimal
from django.urls import reverse
from exercises.forms import SubmitQuestionForm
from django.shortcuts import render, redirect
from dataBaseGuru import settings
from django.apps import apps
import re as re
from django.shortcuts import render,get_object_or_404
from django.template.loader import render_to_string
from rest_framework.views import APIView
from rest_framework.response import Response
import random


# https://docs.djangoproject.com/en/2.2/topics/db/sql/ -> preluat
def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]
###########################

def get_models_info():
    tabelListObject = []
    tabelListName = []
    tabelFields = []
    allTableFieldsDictList = []

    excModels = apps.get_app_config('exercises').get_models()
    for tabel in excModels:
        if 'Exercise' not in str(tabel) and 'Progress' not in str(tabel):
            tabelListObject.append(tabel)
            tabelFields.append(tabel._meta.get_fields())

    for table in re.findall(r'\.models\.([A-Z][A-Za-z]*)\'>', str(tabelListObject)):
        tabelListName.append(table)

    for allFields in range(0, len(tabelFields)):
        fieldList = re.findall(r'\.fields\.(related\.)*(([A-Z][a-z]*)*): ([A-Za-z_-]*)>', str(tabelFields[allFields]))
        toupleFieldList = ()
        listOfFields = []
        tableFieldsDict = {}
        for field in fieldList:
            toupleFieldList = (field[1], field[3])
            listOfFields.append(toupleFieldList)
        tableFieldsDict = {tabelListName[allFields]: listOfFields}
        allTableFieldsDictList.append(tableFieldsDict)

    return allTableFieldsDictList


class ExerciseList(LoginRequiredMixin, ListView):
    template_name = 'exercises/exercise_list.html'
    model = models.Exercise
    context_object_name = 'exercises'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = accounts_models.TeacherRequest.objects.get(teacherRequest=accounts_models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = accounts_models.AdminRequest.objects.get(adminRequest=accounts_models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested
        context['score'] = currentUserProfile.score
        return context


class Exercise(LoginRequiredMixin, DetailView):
    context_object_name = 'exercise'
    model = models.Exercise
    template_name = 'exercises/exercise.html'


    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = accounts_models.TeacherRequest.objects.get(teacherRequest=accounts_models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = accounts_models.AdminRequest.objects.get(adminRequest=accounts_models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested


# IN CAZUL IN CARE VREI XML
        # tree = et.parse(r'D:\github\licenta\dataBaseGuru\exercises\static\tables.xml')
        # root = tree.getroot()
        # context['myTables'] = root

        context['dbTables'] = get_models_info()

        return context


    def dispatch(self, request, *args, **kwargs):
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        try:
            answered = models.Progress.objects.filter(id_question= self.kwargs.get('pk'),
                                                      id_student=currentUserProfile).count()
        except ObjectDoesNotExist:
            answered = 0

        if answered > 0:
            return HttpResponseRedirect(reverse('exercises:exercises_index'))
        else:
            return super(Exercise, self).dispatch(request, *args, **kwargs)


def testQuery(query):

    errors = []
    info = []
    columns = []
    queryResDict = []

    if query.find('delete') != -1 or query.find('insert') != -1 or query.find('drop') != -1 or query.find('update') != -1:
        query = 'You are not allowed to use \'Drop\', \'Delete\', \'Insert\' or \'Update\''
        errors.append(query)

    else:
        if query != '':

            if query.lower().find('select')  == -1:
                errors.append('Missing \'select\' keyword')

            elif query.lower().find('from')  == -1:
                errors.append('Missing \'from\' keyword')

            else:
                if query.lower().find('*') == -1:
                    if query.lower()[query.lower().index('select'):query.lower().index('from')].find('.id') == -1:
                        fromModel = query.lower()[query.lower().index('from'):].split(' ')[1]
                        query = query.lower()[:7] + fromModel + '.id' + ', ' + query.lower()[7:]

                err1 = err2 = ''
                queryResDict = queryInfo = query

                with connection.cursor() as cursor:
                    try:
                        cursor.execute(queryResDict)
                        queryResDict = dictfetchall(cursor)

                        for i in queryResDict[0]:
                            columns.append(i)

                    except Exception as e:
                        err1 = str(e)

                with connection.cursor() as cursor:
                    try:
                        cursor.execute(queryInfo)
                        queryInfo = cursor.fetchall()

                        for j in queryInfo:
                            info.append(j)

                    except Exception as e:
                        err2 = str(e)

                if err1 != '' and err1 == err2:
                    errors.append(err1)
                elif err1 == '' and err1 != err2:
                    errors.append(err2)
                elif err2 == '' and err1 != err2:
                    errors.append(err1)

        else:
            errors.append('Query string is empty!')

    return (columns, info, queryResDict, errors)


def previewSolution(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    context = dict()

    columns, info, queryResDict, errors = testQuery(request.GET.get('userQuery'))

    context['columns'] = columns
    context['info'] = info
    context['userQueryError'] = errors

    return JsonResponse(context)


def submitSolution(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    context = dict()

    userQueryTextAux = userQueryText = request.GET.get('userQuery')
    user_columns, user_info, user_queryResDict, user_errors = testQuery(userQueryTextAux)

    context['columns'] = user_columns
    context['info'] = user_info
    context['userQueryError'] = user_errors

    if len(user_errors) == 0:

        user_columns, user_info, user_queryResDict, user_errors = testQuery(userQueryText)

        solution = models.Exercise.objects.get(id=int(request.GET.get('pk')))
        solution_columns, solution_info, solution_queryResDict, solution_errors = testQuery(solution.answer.lower())

        partialColumnsPoints = solution.partialColumnsPoints
        totalColumnsPoints = solution.totalColumnsPoints
        columnPercentage = solution.columnPercentage

        partialEntryPoints = solution.partialEntryPoints
        totalEntryPoints = solution.totalEntryPoints
        entryPercentage = solution.entryPercentage

        bonusPoints = solution.bonusPoints

        points = 0
        count_columns = 0
        count_entries = 0
        all_columns_in_order = 0
        all_entries_in_order = 0
        TWOPLACES = Decimal(10) ** -2

        if solution_columns == user_columns:
            points = points + totalColumnsPoints

            all_columns_in_order = 1

        else:
            for i in solution_columns:
                for j in user_columns:
                    if i == j:
                        count_columns = count_columns + 1
            if count_columns <= len(solution_columns) and partialColumnsPoints:
                pointsPerColumn = Decimal(columnPercentage / 100).quantize(TWOPLACES) * totalColumnsPoints
                points = points + pointsPerColumn * (count_columns - 1)



        if solution_info == user_info:
            points = points + totalEntryPoints

            all_entries_in_order = 1

        else:
            for solution_entry_list in solution_info:
                for user_entry_list in user_info:
                    if all(i in solution_entry_list for i in user_entry_list):
                        count_entries = count_entries + 1
            if count_entries <= len(solution_info) and partialEntryPoints:
                pointsPerEntry = Decimal(entryPercentage/ 100).quantize(TWOPLACES) * totalEntryPoints
                points = points + pointsPerEntry * count_entries


        if all_entries_in_order and all_columns_in_order:
            points = points + bonusPoints

        currentUserProfile = accounts_models.UserProfile.objects.get(user=request.user)
        progress = models.Progress(id_question=solution,
                                   id_student=currentUserProfile,
                                   user_answer=userQueryText,
                                   points=Decimal(points).quantize(TWOPLACES))
        progress.save()
        totalScore = currentUserProfile.score = currentUserProfile.score + Decimal(points).quantize(TWOPLACES)
        currentUserProfile.save()


        answeredQuestions = []
        allQuestions = models.Exercise.objects.all()
        try:
            progress = models.Progress.objects.filter(id_student=currentUserProfile)
        except Exception as e:
            progress = False

        if progress:
            for i in progress:
                try:
                    answeredQuestions.append(models.Exercise.objects.get(id=i.id_question.id))
                except Exception as e:
                    answeredQuestions = []
        else:
            answeredQuestions = []

        allQuestions = [i for i in allQuestions]
        allQuestions = set(allQuestions)
        answeredQuestions = set(answeredQuestions)
        remainingQuestions = allQuestions.difference(answeredQuestions)

        if len(allQuestions) == len(answeredQuestions):
            nextQuestion = -1

        else:
            if len(remainingQuestions) == 1:
                nextQuestion = next(iter(remainingQuestions)).id

            else:
                found = False
                for i in remainingQuestions:
                    if int(request.GET.get('pk')) < i.id:
                        nextQuestion = i.id
                        found = True
                        break

                if not found:
                    for i in remainingQuestions:
                        nextQuestion = i.id
                        break


        context['nextQuestion'] = nextQuestion
        context['questionAnswered'] = 1
        context['points'] = Decimal(points).quantize(TWOPLACES)
        context['totalScore'] = totalScore
        return JsonResponse(context)

    return JsonResponse(context)


def submitQuestion(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    currentUserProfile = accounts_models.UserProfile.objects.get(user=request.user)

    if not currentUserProfile.is_teacher:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    teacherProfile = accounts_models.Teacher.objects.get(teacher= currentUserProfile)


# IN CAZUL IN CARE VREI XML
    # tree = et.parse(r'D:\github\licenta\dataBaseGuru\exercises\static\tables.xml')
    # root = tree.getroot()

    if request.method == 'POST':
        question_form = SubmitQuestionForm(data=request.POST)

        answer = request.POST.get('answer')
        if question_form.is_valid():
            question = question_form.save(commit=False)
            question.teacherCreator = teacherProfile
            question.answer = answer
            question.save()
            return HttpResponseRedirect(reverse('exercises:exercises_index'))
        else:
            print(question_form.errors)
    else:
        question_form = SubmitQuestionForm()


    try:
        teacherRequested = accounts_models.TeacherRequest.objects.get(teacherRequest=accounts_models.Teacher.objects.get(teacher=currentUserProfile))
        teacherRequested = True
    except ObjectDoesNotExist:
        teacherRequested = False
    try:
        adminRequested = accounts_models.AdminRequest.objects.get(adminRequest=accounts_models.CustomAdmin.objects.get(admin=currentUserProfile))
        adminRequested = True
    except ObjectDoesNotExist:
        adminRequested = False
    return render(request, 'exercises/submitQuestion.html',
                  {'is_teacher': currentUserProfile.is_teacher,
                   'is_admin': currentUserProfile.is_admin,
                   'question_form': question_form,
                   'userpk': currentUserProfile.id,
                   # 'myTables': root,
                   'dbTables': get_models_info(),
                   'teacherRequested':teacherRequested,
                   'adminRequested':adminRequested})


class ManageQuestions(LoginRequiredMixin, ListView):
    template_name = 'exercises/manageQuestions.html'
    model = models.Exercise
    context_object_name = 'questions'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = accounts_models.TeacherRequest.objects.get(teacherRequest=accounts_models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = accounts_models.AdminRequest.objects.get(adminRequest=accounts_models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested
        context['teacher'] = accounts_models.Teacher.objects.get(teacher= currentUserProfile)
        return context

    def get_queryset(self):
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        currentTeacher = accounts_models.Teacher.objects.get(teacher= currentUserProfile)
        postedExercises = models.Exercise.objects.filter(teacherCreator= currentTeacher)
        return postedExercises


def question_delete(request, id):

    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    currentUserProfile = accounts_models.UserProfile.objects.get(user=request.user)

    try:
        teacherRequested = accounts_models.TeacherRequest.objects.get(teacherRequest=accounts_models.Teacher.objects.get(teacher=currentUserProfile))
        teacherRequested = True
    except ObjectDoesNotExist:
        teacherRequested = False

    try:
        adminRequested = accounts_models.AdminRequest.objects.get(adminRequest=accounts_models.CustomAdmin.objects.get(admin=currentUserProfile))
        adminRequested = True
    except ObjectDoesNotExist:
        adminRequested = False

    if not currentUserProfile.is_teacher and not currentUserProfile.user.is_superuser:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    data = dict()
    question = get_object_or_404(models.Exercise, id=id)
    if request.method == "POST":
        question.delete()
        data['form_is_valid'] = True
        currentTeacher = accounts_models.Teacher.objects.get(teacher= currentUserProfile)
        questions = models.Exercise.objects.filter(teacherCreator= currentTeacher)
        data['manageQuestions'] = render_to_string('exercises/manageQuestions2.html', {'questions': questions,
                                                                                 'teacherRequested': teacherRequested,
                                                                                 'adminRequested': adminRequested,
                                                                                  'is_teacher': currentUserProfile.is_teacher,
                                                                                  'is_admin': currentUserProfile.is_admin
                                                                                  },
                                                   request=request)
    else:
        context = {'question': question, 'teacherRequested': teacherRequested, 'adminRequested': adminRequested,
                   'is_teacher': currentUserProfile.is_teacher,
                   'is_admin': currentUserProfile.is_admin
                   }
        data['html_form'] = render_to_string('exercises/question_delete.html', context, request=request)

    return JsonResponse(data)


class History(LoginRequiredMixin, ListView):
    template_name = 'exercises/history.html'
    model = models.Progress
    context_object_name = 'exercises'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = accounts_models.TeacherRequest.objects.get(teacherRequest=accounts_models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = accounts_models.AdminRequest.objects.get(adminRequest=accounts_models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested
        return context

    def get_queryset(self):
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        progress = models.Progress.objects.filter(id_student= currentUserProfile)
        return progress


class SeeExercise(LoginRequiredMixin, DetailView):
    context_object_name = 'exercise'
    model = models.Exercise
    template_name = 'exercises/exerciseForHistory.html'


    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = accounts_models.TeacherRequest.objects.get(teacherRequest=accounts_models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = accounts_models.AdminRequest.objects.get(adminRequest=accounts_models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested
        context['dbTables'] = get_models_info()

        return context


    def dispatch(self, request, *args, **kwargs):
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        try:
            answered = models.Progress.objects.filter(id_question= self.kwargs.get('pk'),
                                                      id_student=currentUserProfile).count()
        except ObjectDoesNotExist:
            answered = 0

        if answered > 0:
            return super(SeeExercise, self).dispatch(request, *args, **kwargs)
        else:
            return HttpResponseRedirect(reverse('exercises:exercises_index'))


class StatisticsHome(View):
    def get(self, request, pk, id, *args, **kwargs):
        context=dict()
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = accounts_models.TeacherRequest.objects.get(
                teacherRequest=accounts_models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = accounts_models.AdminRequest.objects.get(
                adminRequest=accounts_models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested
        context['questionPk'] = pk
        context['idQuestion'] = id
        top10 = models.Progress.objects.filter(id_question=pk).order_by('-points')[0:10]
        context['top10'] = top10
        context['topDown'] = models.Progress.objects.filter(id_question=pk).exclude(id__in=top10).order_by('points')[0:10]

        return render(request, 'exercises/statistic.html', context)

    def dispatch(self, request, *args, **kwargs):
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        exercise = models.Exercise.objects.get(id=self.kwargs.get('pk'))
        if currentUserProfile.is_teacher:
            if exercise.teacherCreator == accounts_models.Teacher.objects.get(teacher=currentUserProfile):
                return super(StatisticsHome, self).dispatch(request, *args, **kwargs)
            else:
                return HttpResponseRedirect(reverse('exercises:exercises_index'))
        else:
            return HttpResponseRedirect(reverse('exercises:exercises_index'))



# https://www.chartjs.org/docs/latest/getting-started/usage.html -> adaptare
class Statistics(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request, pk, format=None):
        excCount = models.Exercise.objects.get(id=pk)
        correct = models.Progress.objects.filter(id_question=excCount).filter(points=150).count()
        wrong = models.Progress.objects.filter(id_question=excCount).filter(points__lt = 150).count()

        labels = ['Correct Answers', 'Wrong Answers']
        default_items = [correct, wrong]
        data = {
            "labels": labels,
            "default": default_items,
        }
        return Response(data)

    def dispatch(self, request, *args, **kwargs):
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        exercise = models.Exercise.objects.get(id=self.kwargs.get('pk'))
        if currentUserProfile.is_teacher:
            if exercise.teacherCreator == accounts_models.Teacher.objects.get(teacher=currentUserProfile):
                return super(Statistics, self).dispatch(request, *args, **kwargs)
            else:
                return HttpResponseRedirect(reverse('exercises:exercises_index'))
        else:
            return HttpResponseRedirect(reverse('exercises:exercises_index'))



class AllQuestionsStatistics(View):
    def get(self, request, pk, *args, **kwargs):
        context=dict()
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = accounts_models.TeacherRequest.objects.get(
                teacherRequest=accounts_models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = accounts_models.AdminRequest.objects.get(
                adminRequest=accounts_models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested

        teacher = accounts_models.Teacher.objects.get(id=pk)
        context['currentTeacher'] = teacher
        context['currentTeacherPk'] = pk

        count = 1
        max = 0
        teacherQuestions = models.Exercise.objects.filter(teacherCreator=teacher)
        idQ = False
        mostAnswered = False
        for question in teacherQuestions:
            current = models.Progress.objects.filter(id_question=question).count()
            if current > max:
                max = current
                mostAnswered = question
                idQ = count
            count = count + 1

        context['mostAnsweredQuestion'] = mostAnswered
        context['mostAnsweredQuestionId'] = idQ

        count = 1
        max = 0
        idQ = False
        mostGoodAnswered = False
        for question in teacherQuestions:
            totalPoints = question.totalColumnsPoints + question.totalEntryPoints + question.bonusPoints
            current = models.Progress.objects.filter(id_question=question).filter(points=totalPoints).count()
            if current > max:
                max = current
                mostGoodAnswered = question
                idQ = count
            count = count + 1

        context['mostGoodAnswered'] = mostGoodAnswered
        context['bestAnswerID'] = idQ


        count = 1
        max = 0
        idQ = False
        mostWrongAnswered = False
        for question in teacherQuestions:
            totalPoints = question.totalColumnsPoints + question.totalEntryPoints + question.bonusPoints
            current = models.Progress.objects.filter(id_question=question).filter(points__lt=totalPoints).count()
            if current > max:
                max = current
                mostWrongAnswered = question
                idQ = count
            count = count + 1

        context['mostWrongAnswered'] = mostWrongAnswered
        context['worstAnswerID'] = idQ

        return render(request, 'exercises/allQuestionsStatistic.html', context)




    def dispatch(self, request, *args, **kwargs):
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        teacher = accounts_models.Teacher.objects.get(teacher=currentUserProfile)
        teacherRequested = accounts_models.Teacher.objects.get(id=self.kwargs.get('pk'))
        if currentUserProfile.is_teacher:
            if teacher == teacherRequested:
                return super(AllQuestionsStatistics, self).dispatch(request, *args, **kwargs)
            else:
                return HttpResponseRedirect(reverse('exercises:exercises_index'))
        else:
            return HttpResponseRedirect(reverse('exercises:exercises_index'))



# https://www.chartjs.org/docs/latest/getting-started/usage.html -> adaptare
class StatisticsForAllQuestions(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request, pk, format=None):
        labels=[]
        default_items=[]
        bgColor = []
        bdColor = []
        teacher = accounts_models.Teacher.objects.get(id=pk)
        teacherQuestions = models.Exercise.objects.filter(teacherCreator=teacher)
        count = 1
        for question in teacherQuestions:
            labels.append('Question ' + str(count))
            default_items.append(models.Progress.objects.filter(id_question=question).count())
            color = 'rgba(' + str(random.randint(0,255)) + ',' + str(random.randint(0,255)) + ',' + str(random.randint(0,255)) + ','
            bgColor.append(color + '0.2)')
            bdColor.append(color + '1)')
            count = count + 1


        default_items2=[]
        bgColor2 = []
        bdColor2 = []
        for question in teacherQuestions:
            totalPoints = question.totalColumnsPoints + question.totalEntryPoints + question.bonusPoints
            try:
                aux = models.Progress.objects.filter(id_question= question).filter(points=totalPoints).count()
            except:
                aux = 0
            default_items2.append(aux)
            color = 'rgba(' + str(random.randint(0, 255)) + ',' + str(random.randint(0, 255)) + ',' + str(random.randint(0, 255)) + ','
            bgColor2.append(color + '0.2)')
            bdColor2.append(color + '1)')


        default_items3 = []
        bgColor3 = []
        bdColor3 = []
        for question in teacherQuestions:
            totalPoints = question.totalColumnsPoints + question.totalEntryPoints + question.bonusPoints
            try:
                aux = models.Progress.objects.filter(id_question= question).filter(points__lt=totalPoints).count()
            except:
                aux = 0
            default_items3.append(aux)
            color = 'rgba(' + str(random.randint(0, 255)) + ',' + str(random.randint(0, 255)) + ',' + str(random.randint(0, 255)) + ','
            bgColor3.append(color + '0.2)')
            bdColor3.append(color + '1)')


        data = {
            "labels": labels,
            "default": default_items,
            "bgColor": bgColor,
            "bdColor": bdColor,

            "labels2": labels,
            'default2': default_items2,
            'bgColor2' : bgColor2,
            'bdColor2': bdColor2,

            "labels3": labels,
            'default3': default_items3,
            'bgColor3': bgColor3,
            'bdColor3': bdColor3
        }


        return Response(data)

    def dispatch(self, request, *args, **kwargs):
        currentUserProfile = accounts_models.UserProfile.objects.get(user=self.request.user)
        teacher = accounts_models.Teacher.objects.get(teacher=currentUserProfile)
        teacherRequested = accounts_models.Teacher.objects.get(id=self.kwargs.get('pk'))
        if currentUserProfile.is_teacher:
            if teacher == teacherRequested:
                return super(StatisticsForAllQuestions, self).dispatch(request, *args, **kwargs)
            else:
                return HttpResponseRedirect(reverse('exercises:exercises_index'))
        else:
            return HttpResponseRedirect(reverse('exercises:exercises_index'))