from django.contrib import admin
from accounts.models import UserProfile, Teacher, CustomAdmin, TeacherRequest, AdminRequest

# Register your models here.
admin.site.register(UserProfile)
admin.site.register(Teacher)
admin.site.register(CustomAdmin)
admin.site.register(TeacherRequest)
admin.site.register(AdminRequest)