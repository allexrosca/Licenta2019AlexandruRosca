# https://www.udemy.com/python-and-django-full-stack-web-developer-bootcamp/ -> adaptat
# https://stackoverflow.com/questions/31130706/dropdown-in-django-model -> adaptat


from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.contrib.auth.models import AbstractUser

# Create your models here.
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete= models.CASCADE)
    is_teacher = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
    score = models.DecimalField(max_digits=19, decimal_places=2, default=0.00)

    GENDER = (
        ('N', 'Neutral'),
        ('M', 'Male'),
        ('F', 'Female'),
    )

    STUDY = (
        ('N', 'Nothing'),
        ('P', 'Primary School'),
        ('H', 'High School'),
        ('U', 'University'),
    )

    firstName = models.CharField(max_length=20, blank=True, null=True)
    lastName = models.CharField(max_length=20, blank=True, null=True)
    age = models.PositiveIntegerField(blank=True, null=True)
    gender = models.CharField(max_length=1, choices=GENDER, default='N', blank=True, null=True)
    qualification = models.CharField(max_length=1, choices=STUDY, default='N', blank=True, null=True)
    city = models.CharField(max_length=20, blank=True, null=True)
    profilePicture = models.ImageField(upload_to='profile_pics', default='default.jpg', blank = True, null=True)

    def __str__(self):
        return self.user.username

class Teacher(models.Model):
    teacher = models.OneToOneField(UserProfile, on_delete= models.CASCADE)

    rank = models.CharField(max_length=50, blank=False, null=False)
    teachInstitute = models.CharField(max_length=50, blank=False, null=False)
    def __str__(self):
        return self.teacher.user.username


class CustomAdmin(models.Model):
    admin = models.OneToOneField(UserProfile, on_delete= models.CASCADE)

    phoneNumber = models.CharField(max_length=10, blank=False, null=False)
    programmingLanguages = models.CharField(max_length=50, blank=False)
    def __str__(self):
        return self.admin.user.username


class TeacherRequest(models.Model):
    teacherRequest = models.OneToOneField(Teacher, on_delete= models.CASCADE)

    reason = models.CharField(max_length=100, blank=False)
    specialty = models.CharField(max_length=50, blank=False)
    cv = models.FileField(upload_to='cvs/', blank=True, null= True)
    def __str__(self):
        return self.teacherRequest.teacher.user.username



class AdminRequest(models.Model):
    adminRequest = models.OneToOneField(CustomAdmin, on_delete= models.CASCADE)

    shortDescription = models.CharField(max_length=100, blank=False)
    cv = models.FileField(upload_to='cvs', blank=True, null= True)
    def __str__(self):
        return self.adminRequest.admin.user.username
