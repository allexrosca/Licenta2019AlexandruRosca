# https://www.udemy.com/python-and-django-full-stack-web-developer-bootcamp/ -> adaptat
# https://docs.djangoproject.com/en/2.2/topics/auth/default/ -> adaptat
# https://docs.djangoproject.com/en/2.2/topics/class-based-views/generic-display/ -> adaptat
# https://docs.djangoproject.com/en/2.2/ref/models/querysets/#django.db.models.query.QuerySet.get -> adaptat
# https://docs.djangoproject.com/en/2.1/ref/models/querysets/ -> adaptat
# https://github.com/mhadiahmed/CRUD-System?fbclid=IwAR2p07Hq2NHoe-53iP-Olr38oOY1i78dqa9o8U2jKyb8jlbtlvCsRXul_eQ ->adaptat


from ctypes import c_bool

from django.shortcuts import render, redirect
from django.views.generic import View, TemplateView, DetailView, ListView
from accounts.forms import RegisterForm, LoginForm, TeacherRequestForm, UserProfileForm, TeacherForm, AdminForm, AdminRequestForm, ProfilePictureForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from dataBaseGuru import settings
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from accounts import models
from exercises import models as exercises_models
from django.core.exceptions import ObjectDoesNotExist
from django.template.loader import render_to_string
from django.http import JsonResponse
from django.shortcuts import render,get_object_or_404
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
import json
from PIL import Image
from decimal import Decimal



################ USERS OFFLINE #################
def register(request):
    registered = False

    if request.user.is_authenticated:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    if request.method == 'POST':
        user_form = RegisterForm(data=request.POST)

        if user_form.is_valid():
            user = user_form.save(commit=False)
            username = user_form.cleaned_data['username']
            password = user_form.cleaned_data['password']

            try:
                validate_password(password, user)
            except ValidationError as e:
                user_form.add_error('password', e)
                return render(request, 'accounts/users/registration.html', {'user_form': user_form})

            user.set_password(password)
            user.save()
            registered = True
            return HttpResponseRedirect(reverse('accounts:user_login'))
        else:
            print(user_form.errors)
    else:
        user_form = RegisterForm()
    return render(request, 'accounts/users/registration.html', {'user_form': user_form, 'registered': registered})


def user_login(request):

    if request.user.is_authenticated:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    userLoginform = LoginForm(request.POST or None)
    if request.method == 'POST' and userLoginform.is_valid():
        user = userLoginform.login(request)
        if user:
            login(request, user)
            return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    return render(request,'accounts/users/login.html',{'userLoginform':userLoginform})


################ USERS #################
class ConnectedHomePageView(LoginRequiredMixin, TemplateView):
    template_name = 'accounts/connectedHomePage.html'
    login_url = 'accounts/users/login/'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        currentUserProfile = models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested
        return context


class AllUsersProfile(LoginRequiredMixin, DetailView):
    context_object_name = 'userProfile_detail'
    model = models.UserProfile
    template_name = 'accounts/users/userProfile.html'
    login_url = 'accounts/users/login/'


    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        currentUserProfile = models.UserProfile.objects.get(id=self.kwargs['pk'])
        userProfile = models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = userProfile.id
        context['is_teacher'] = userProfile.is_teacher
        context['is_admin'] = userProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested

        if currentUserProfile.is_teacher:
            try:
                teacherProfile = models.Teacher.objects.get(teacher=currentUserProfile)
                context['teacherProfile'] = teacherProfile
            except ObjectDoesNotExist:
                newTeacher = models.Teacher(teacher=currentUserProfile, rank='', teachInstitute='')
                newTeacher.save()
                context['teacherProfile'] = newTeacher

        if currentUserProfile.is_admin:
            try:
                adminProfile = models.CustomAdmin.objects.get(admin=currentUserProfile)
                context['adminProfile'] = adminProfile
            except ObjectDoesNotExist:
                newAdmin = models.CustomAdmin(admin=currentUserProfile, identityCardSeries='', adress='')
                newAdmin.save()

        try:
            totalExercises = exercises_models.Exercise.objects.all().count()
        except ObjectDoesNotExist:
            totalExercises = 0

        try:
            solvedExercises = exercises_models.Progress.objects.filter(id_student=currentUserProfile).count()
        except ObjectDoesNotExist:
            solvedExercises = 0

        context['totalExercises'] = totalExercises
        context['solvedExercises'] = solvedExercises

        theBest = models.UserProfile.objects.order_by('-score')
        count = 0
        leaderboardPosition = -1

        if theBest[0] == currentUserProfile:
            context['leaderboardPosition'] = 'You are The First!'
            context['nextPosition'] = "You can't get any higher!"
        else:
            for i in theBest:
                if i == currentUserProfile:
                    leaderboardPosition = count
                count = count + 1
            context['leaderboardPosition'] = leaderboardPosition + 1

            nextPosition = theBest[leaderboardPosition - 1].score - currentUserProfile.score
            if nextPosition == 0:
                context['nextPosition'] = 0.01
            else:
                TWOPLACES = Decimal(10) ** -2
                context['nextPosition'] = Decimal(nextPosition).quantize(TWOPLACES) + Decimal(0.01).quantize(TWOPLACES)

        return context


def editProfile(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    context= dict()
    pk = request.GET.get('pk')
    lastName = request.GET.get('lastName')
    firstName = request.GET.get('firstName')
    age = request.GET.get('age')
    city = request.GET.get('city')
    qualification = request.GET.get('qualification')
    rank = request.GET.get('rank')
    teachInstitute = request.GET.get('teachInstitute')
    gender = request.GET.get('gender')


    userProfile = models.UserProfile.objects.get(id=pk)
    userProfile.gender = gender
    userProfile.qualification = qualification
    try:
        teacherProfile = models.Teacher.objects.get(teacher=userProfile)
    except ObjectDoesNotExist:
        teacherProfile = None

    userProfile.lastName = lastName[:20].replace('\n',' ')
    userProfile.firstName = firstName[:20].replace('\n',' ')
    userProfile.city = city[:20].replace('\n',' ')
    if age.isdigit() and (int(age) > 150):
        age = int(age[0:3])
    elif not age.isdigit():
        age = 0

    userProfile.age = age
    userProfile.save()

    if teacherProfile:
        teacherProfile.rank = rank[:50].replace('\n', ' ')
        teacherProfile.teachInstitute = teachInstitute[:50].replace('\n', ' ')
        teacherProfile.save()

    return JsonResponse(context)


def editProfilePicture(request, pk):
    data = dict()
    if request.is_ajax():
        form = ProfilePictureForm(request.POST, request.FILES)
        if form.is_valid():
            user = models.User.objects.get(id=pk)
            user_profile = models.UserProfile.objects.get(user=user)
            try:
                img = Image.open(form.cleaned_data['image'])
                img.verify()
                user_profile.profilePicture=form.cleaned_data['image']
            except:
                pass
            user_profile.save()

    return JsonResponse(data)


################ RIGHTS REQUESTS #################
def teacherRequest(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    currentUserProfile = models.UserProfile.objects.get(user=request.user)
    try:
        adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
        adminRequested = True
    except ObjectDoesNotExist:
        adminRequested = False

    try:
        alreadyTeacher = models.Teacher.objects.get(teacher=currentUserProfile)
        alreadyTeacherRequested = models.TeacherRequest.objects.get(teacherRequest=alreadyTeacher)
        alreadyTeacherRequested = True
    except ObjectDoesNotExist:
        alreadyTeacherRequested = None

    if currentUserProfile.is_teacher:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    if alreadyTeacherRequested:
        return HttpResponseRedirect(reverse('accounts:all_users_profile', args={currentUserProfile.id}))


    if request.method == 'POST':
        teacher_form = TeacherForm(data=request.POST)
        teacherRequest_form = TeacherRequestForm(request.POST, request.FILES)

        if teacher_form.is_valid() and teacherRequest_form.is_valid():
            teacherAux = teacher_form.save(commit = False)
            teacherAux.teacher = currentUserProfile
            teacherAux.save()
            teacherReq = teacherRequest_form.save(commit = False)
            teacherReq.teacherRequest = teacherAux
            if 'cv' in request.FILES:
                teacherReq.cv = request.FILES.get('cv')
            teacherReq.save()
            return HttpResponseRedirect(reverse('accounts:user_connectedHomePage'))
        else:
            print(teacherRequest_form.errors)
    else:
        teacher_form = TeacherForm()
        teacherRequest_form = TeacherRequestForm()
    return render(request, 'accounts/rightsRequest/teacherRightsRequest.html', {'is_teacher':currentUserProfile.is_teacher,
                                                                                'is_admin':currentUserProfile.is_admin,
                                                                                'teacher_form':teacher_form,
                                                                                'teacherRequest_form': teacherRequest_form,
                                                                                'userpk':currentUserProfile.id,
                                                                                'teacherRequested': alreadyTeacherRequested,
                                                                                'adminRequested': adminRequested})


def adminRequest(request):

    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    currentUserProfile = models.UserProfile.objects.get(user=request.user)
    try:
        teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
        teacherRequested = True
    except ObjectDoesNotExist:
        teacherRequested = False
    try:
        alreadyAdmin = models.CustomAdmin.objects.get(admin=currentUserProfile)
        alreadyAdminRequested = models.AdminRequest.objects.get(adminRequest=alreadyAdmin)
        alreadyAdminRequested = True
    except ObjectDoesNotExist:
        alreadyAdminRequested = None

    if currentUserProfile.is_admin:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    if alreadyAdminRequested:
        return HttpResponseRedirect(reverse('accounts:all_users_profile', args={currentUserProfile.id}))

    if request.method == 'POST':
        admin_form = AdminForm(data=request.POST)
        adminRequest_form = AdminRequestForm(request.POST, request.FILES)

        if admin_form.is_valid() and adminRequest_form.is_valid():
            adminAux = admin_form.save(commit = False)
            adminAux.admin = currentUserProfile
            adminAux.save()
            adminReq = adminRequest_form.save(commit = False)
            adminReq.adminRequest = adminAux
            if 'cv' in request.FILES:
                adminReq.cv = request.FILES.get('cv')
            adminReq.save()
            return HttpResponseRedirect(reverse('accounts:user_connectedHomePage'))

        else:
            print(adminRequest_form.errors)
    else:
        admin_form = AdminForm()
        adminRequest_form = AdminRequestForm()
    return render(request, 'accounts/rightsRequest/adminRightsRequest.html', {'admin_form':admin_form,
                                                                              'adminRequest_form': adminRequest_form,
                                                                              'userpk':currentUserProfile.id,
                                                                              'is_admin':currentUserProfile.is_admin,
                                                                              'is_teacher':currentUserProfile.is_teacher,
                                                                              'teacherRequested': teacherRequested,
                                                                              'adminRequested': alreadyAdminRequested})


################ MANAGE TEACHERS + REQUESTS #################
class Teacher_listView(LoginRequiredMixin, ListView):
    model = models.Teacher
    template_name = 'accounts/admin/teacherHandle/teacher_list/teachersList.html'

    def dispatch(self, request, *args, **kwargs):
        currentUserProfile = models.UserProfile.objects.get(user=self.request.user)

        if not request.user.is_authenticated:
            return HttpResponseRedirect(reverse('accounts:user_login'))

        if not currentUserProfile.is_admin and not currentUserProfile.user.is_superuser:
            return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))
        else:
            return super(Teacher_listView, self).dispatch(request, *args, **kwargs)


    def get_context_data(self, **kwargs):
        currentUserProfile = models.UserProfile.objects.get(user=self.request.user)

        try:
            teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False

        try:
            adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False

        nonTeacher = models.UserProfile.objects.filter(is_teacher=False)
        if currentUserProfile.user.is_superuser:
            teacher = models.Teacher.objects.all().exclude(teacher__in=nonTeacher)
        else:
            superUsers = models.User.objects.filter(is_superuser=True)
            superUsersProfile = models.UserProfile.objects.filter(user__in=superUsers)
            teacher = models.Teacher.objects.all().exclude(teacher__in=superUsersProfile).exclude(teacher__in=nonTeacher)
        context = {'teachers': teacher,
                   'userpk': currentUserProfile.id,
                   'is_teacher': currentUserProfile.is_teacher,
                   'is_admin': currentUserProfile.is_admin,
                   'teacherRequested': teacherRequested,
                   'adminRequested': adminRequested,
                   'currentUserProfile': currentUserProfile}
        return context


def teacher_delete(request, id):

    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    currentUserProfile = models.UserProfile.objects.get(user=request.user)

    try:
        teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
        teacherRequested = True
    except ObjectDoesNotExist:
        teacherRequested = False

    try:
        adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
        adminRequested = True
    except ObjectDoesNotExist:
        adminRequested = False

    if not currentUserProfile.is_admin and not currentUserProfile.user.is_superuser:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    data = dict()
    teacher = get_object_or_404(models.Teacher, id=id)
    profile = get_object_or_404(models.UserProfile, user=teacher.teacher.user)
    if request.method == "POST":
        profile.is_teacher = False
        profile.save()
        teacher.delete()
        data['form_is_valid'] = True
        nonTeacher = models.UserProfile.objects.filter(is_teacher=False)
        teachers = models.Teacher.objects.all().exclude(teacher__in=nonTeacher)
        data['teachers_list'] = render_to_string('accounts/admin/teacherHandle/teacher_list/teachersList2.html', {'teachers': teachers,
                                                                                                               'teacherRequested': teacherRequested,
                                                                                                               'adminRequested': adminRequested,
                                                                                                                  'is_teacher': currentUserProfile.is_teacher,
                                                                                                                  'is_admin': currentUserProfile.is_admin
                                                                                                                  },
                                                        request=request)
    else:
        context = {'teacher': teacher, 'teacherRequested': teacherRequested, 'adminRequested': adminRequested,
                   'is_teacher':currentUserProfile.is_teacher, 'is_admin': currentUserProfile.is_admin}
        data['html_form'] = render_to_string('accounts/admin/teacherHandle/teacher_list/teacherDelete.html', context, request=request)

    return JsonResponse(data)


class TeacherRequest_listView(LoginRequiredMixin, ListView):
    model = models.TeacherRequest
    template_name = 'accounts/admin/teacherHandle/requests/teacherRequests.html'

    def dispatch(self, request, *args, **kwargs):
        currentUserProfile = models.UserProfile.objects.get(user=request.user)

        if not request.user.is_authenticated:
            return HttpResponseRedirect(reverse('accounts:user_login'))

        if not currentUserProfile.is_admin and not currentUserProfile.user.is_superuser:
            return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))
        else:
            return super(TeacherRequest_listView, self).dispatch(request, *args, **kwargs)


    def get_context_data(self, **kwargs):
        currentUserProfile = models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequestedAux = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
            teacherRequestedAux = False

        try:
            adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False


        if currentUserProfile.user.is_superuser:
            teacherReqs = models.TeacherRequest.objects.all()
        else:
            superUsers = models.User.objects.filter(is_superuser=True)
            superUsersProfile = models.UserProfile.objects.filter(user__in=superUsers)
            superUsersTeacher = models.Teacher.objects.filter(teacher__in=superUsersProfile)
            if teacherRequestedAux:
                teacherReqs = models.TeacherRequest.objects.all().exclude(teacherRequest__in=superUsersTeacher).exclude(teacherRequest=teacherRequestedAux.teacherRequest)
            else:
                teacherReqs = models.TeacherRequest.objects.all().exclude(teacherRequest__in=superUsersTeacher)

        context = {'teacherReqs': teacherReqs,
                   'userpk': currentUserProfile.id,
                   'is_teacher': currentUserProfile.is_teacher,
                   'is_admin': currentUserProfile.is_admin,
                   'teacherRequested': teacherRequested,
                   'adminRequested': adminRequested,
                   'currentUserProfile': currentUserProfile}
        return context


def teacherRequest_delete(request, id):

    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    currentUserProfile = models.UserProfile.objects.get(user=request.user)

    try:
        teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
        teacherRequested = True
    except ObjectDoesNotExist:
        teacherRequested = False

    try:
        adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
        adminRequested = True
    except ObjectDoesNotExist:
        adminRequested = False

    if not currentUserProfile.is_admin and not currentUserProfile.user.is_superuser:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    data = dict()
    teacherReq = get_object_or_404(models.TeacherRequest, id=id)
    teacher = get_object_or_404(models.Teacher, teacher=teacherReq.teacherRequest.teacher)
    if request.method == "POST":
        teacherReq.delete()
        teacher.delete()
        data['form_is_valid'] = True
        teacherReqs = models.TeacherRequest.objects.all()
        data['teacher_request_list'] = render_to_string('accounts/admin/teacherHandle/requests/teacherRequests2.html', {'teacherReqs': teacherReqs,
                                                                                                               'teacherRequested': teacherRequested,
                                                                                                               'adminRequested': adminRequested,
                                                                                                                        'is_teacher': currentUserProfile.is_teacher,
                                                                                                                        'is_admin': currentUserProfile.is_admin
                                                                                                                        },
                                                        request=request)
    else:
        context = {'teacherReq': teacherReq, 'teacherRequested': teacherRequested, 'adminRequested': adminRequested,
                   'is_teacher':currentUserProfile.is_teacher, 'is_admin': currentUserProfile.is_admin}
        data['html_form'] = render_to_string('accounts/admin/teacherHandle/requests/teacherRequestDelete.html', context, request=request)

    return JsonResponse(data)


def teacherRequest_accept(request, id):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    currentUserProfile = models.UserProfile.objects.get(user=request.user)

    try:
        teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
        teacherRequested = True
    except ObjectDoesNotExist:
        teacherRequested = False

    try:
        adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
        adminRequested = True
    except ObjectDoesNotExist:
        adminRequested = False

    if not currentUserProfile.is_admin and not currentUserProfile.user.is_superuser:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    data = dict()
    teacherReq = get_object_or_404(models.TeacherRequest, id=id)
    userprofileid = get_object_or_404(models.UserProfile, id=teacherReq.teacherRequest.teacher.id)
    if request.method == "POST":
        teacherReq.delete()
        userprofileid.is_teacher = True
        userprofileid.save()
        data['form_is_valid'] = True
        teacherReqs = models.TeacherRequest.objects.all()
        data['teacher_request_list'] = render_to_string('accounts/admin/teacherHandle/requests/teacherRequests2.html', {'teacherReqs': teacherReqs,
                                                                                                               'teacherRequested': teacherRequested,
                                                                                                               'adminRequested': adminRequested,
                                                                                                                        'is_teacher': currentUserProfile.is_teacher,
                                                                                                                        'is_admin': currentUserProfile.is_admin
                                                                                                                        },
                                                        request=request)
    else:
        context = {'teacherReq': teacherReq, 'teacherRequested': teacherRequested, 'adminRequested': adminRequested,
                   'is_teacher':currentUserProfile.is_teacher, 'is_admin': currentUserProfile.is_admin}
        data['html_form'] = render_to_string('accounts/admin/teacherHandle/requests/teacherRequestAccept.html', context, request=request)

    return JsonResponse(data)


################ MANAGE ADMINS + REQUESTS #################
class AdminsListView(LoginRequiredMixin, ListView):
    model = models.CustomAdmin
    template_name = 'accounts/admin/adminHandle/admin_list/adminsList.html'
    context_object_name = 'admins'

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_superuser:
            return redirect(settings.LOGIN_REDIRECT_URL)
        else:
            return super(AdminsListView, self).dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        currentUserProfile = models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested
        return context


    def get_queryset(self):
        admins = models.UserProfile.objects.filter(is_admin= True)
        queryset = models.CustomAdmin.objects.filter(admin__in=admins)
        return queryset


def admin_delete(request, id):

    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    currentUserProfile = models.UserProfile.objects.get(user=request.user)

    try:
        teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
        teacherRequested = True
    except ObjectDoesNotExist:
        teacherRequested = False

    try:
        adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
        adminRequested = True
    except ObjectDoesNotExist:
        adminRequested = False

    if not currentUserProfile.user.is_superuser:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    data = dict()
    admin = get_object_or_404(models.CustomAdmin, id=id)
    profile = get_object_or_404(models.UserProfile, user=admin.admin.user)
    if request.method == "POST":
        profile.is_admin = False
        profile.save()
        admin.delete()
        data['form_is_valid'] = True
        nonAdmins = models.UserProfile.objects.filter(is_admin= False)
        admins = models.CustomAdmin.objects.all().exclude(admin__in=nonAdmins)
        data['admins_list'] = render_to_string('accounts/admin/adminHandle/admin_list/adminsList2.html', {'admins': admins,
                                                                                                               'teacherRequested': teacherRequested,
                                                                                                               'adminRequested': adminRequested,
                                                                                                          'is_teacher': currentUserProfile.is_teacher,
                                                                                                          'is_admin': currentUserProfile.is_admin
                                                                                                          },
                                                        request=request)
    else:
        context = {'admin': admin, 'teacherRequested': teacherRequested, 'adminRequested': adminRequested,
                   'is_teacher':currentUserProfile.is_teacher, 'is_admin': currentUserProfile.is_admin}
        data['html_form'] = render_to_string('accounts/admin/adminHandle/admin_list/adminDelete.html', context, request=request)

    return JsonResponse(data)


class AdminRequest_listView(LoginRequiredMixin, ListView):
    model = models.AdminRequest
    template_name = 'accounts/admin/adminHandle/requests/adminRequests.html'

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return HttpResponseRedirect(reverse('accounts:user_login'))

        currentUserProfile = models.UserProfile.objects.get(user=self.request.user)

        if not currentUserProfile.user.is_superuser:
            return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))
        else:
            return super(AdminRequest_listView, self).dispatch(request, *args, **kwargs)


    def get_context_data(self, **kwargs):
        currentUserProfile = models.UserProfile.objects.get(user=self.request.user)

        try:
            teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False

        try:
            adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False

        adminReqs = models.AdminRequest.objects.all()

        context = {'adminReqs': adminReqs,
                   'userpk': currentUserProfile.id,
                   'is_teacher': currentUserProfile.is_teacher,
                   'is_admin': currentUserProfile.is_admin,
                   'teacherRequested': teacherRequested,
                   'adminRequested': adminRequested,
                   'currentUserProfile': currentUserProfile}
        return context


def adminRequest_delete(request, id):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    currentUserProfile = models.UserProfile.objects.get(user=request.user)

    try:
        teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
        teacherRequested = True
    except ObjectDoesNotExist:
        teacherRequested = False

    try:
        adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
        adminRequested = True
    except ObjectDoesNotExist:
        adminRequested = False

    if not currentUserProfile.user.is_superuser:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    data = dict()
    adminReq = get_object_or_404(models.AdminRequest, id=id)
    admin = get_object_or_404(models.CustomAdmin, admin=adminReq.adminRequest.admin)
    if request.method == "POST":
        adminReq.delete()
        admin.delete()
        data['form_is_valid'] = True
        adminReqs = models.AdminRequest.objects.all()
        data['admin_request_list'] = render_to_string('accounts/admin/adminHandle/requests/adminRequests2.html',
                                                      {'adminReqs': adminReqs,
                                                       'teacherRequested': teacherRequested,
                                                       'adminRequested': adminRequested,
                                                       'is_teacher': currentUserProfile.is_teacher,
                                                       'is_admin': currentUserProfile.is_admin
                                                       },
                                                      request=request)
    else:
        context = {'adminReq': adminReq,
                   'teacherRequested': teacherRequested,
                   'adminRequested': adminRequested,
                   'is_teacher':currentUserProfile.is_teacher, 'is_admin': currentUserProfile.is_admin}
        data['admin_form'] = render_to_string('accounts/admin/adminHandle/requests/adminRequestDelete.html', context, request=request)

    return JsonResponse(data)


def adminRequest_accept(request, id):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))

    currentUserProfile = models.UserProfile.objects.get(user=request.user)

    try:
        teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
        teacherRequested = True
    except ObjectDoesNotExist:
        teacherRequested = False

    try:
        adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
        adminRequested = True
    except ObjectDoesNotExist:
        adminRequested = False

    if not currentUserProfile.user.is_superuser:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    data = dict()
    adminReq = get_object_or_404(models.AdminRequest, id=id)
    userprofileid = get_object_or_404(models.UserProfile, id=adminReq.adminRequest.admin.id)
    if request.method == "POST":
        adminReq.delete()
        userprofileid.is_admin = True
        userprofileid.save()
        data['form_is_valid'] = True
        adminReqs = models.AdminRequest.objects.all()
        data['admin_request_list'] = render_to_string('accounts/admin/adminHandle/requests/adminRequests2.html', {'adminReqs': adminReqs,
                                                                                                         'teacherRequested': teacherRequested,
                                                                                                         'adminRequested': adminRequested,
                                                                                                                  'is_teacher': currentUserProfile.is_teacher,
                                                                                                                  'is_admin': currentUserProfile.is_admin
                                                                                                                  },
                                                      request=request)
    else:
        context = {'adminReq': adminReq,
                   'teacherRequested': teacherRequested,
                   'adminRequested': adminRequested,
                   'is_teacher':currentUserProfile.is_teacher, 'is_admin': currentUserProfile.is_admin}
        data['admin_form'] = render_to_string('accounts/admin/adminHandle/requests/adminRequestAccept.html', context, request=request)

    return JsonResponse(data)


class UsersListView(LoginRequiredMixin, ListView):
    model = models.UserProfile
    template_name = 'accounts/admin/userHandle/usersList.html'
    context_object_name = 'users'

    def dispatch(self, request, *args, **kwargs):
        currentUserProfile = models.UserProfile.objects.get(user=request.user)

        if not request.user.is_superuser and not currentUserProfile.is_admin:
            return HttpResponseRedirect(reverse('accounts:user_connectedHomePage'))
        else:
            return super(UsersListView, self).dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        currentUserProfile = models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested
        return context


    def get_queryset(self):
        if self.request.user.is_superuser:
            queryset = models.UserProfile.objects.filter(is_teacher=False).filter(is_admin=False)
        else:
            superUsers = models.User.objects.filter(is_superuser=True)
            queryset = models.UserProfile.objects.filter(is_teacher=False).filter(is_admin=False).exclude(user__in=superUsers)
        return queryset


def user_delete(request, id):

    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse('accounts:user_login'))
    currentUserProfile = models.UserProfile.objects.get(user=request.user)

    try:
        teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
        teacherRequested = True
    except ObjectDoesNotExist:
        teacherRequested = False

    try:
        adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
        adminRequested = True
    except ObjectDoesNotExist:
        adminRequested = False

    if not currentUserProfile.is_admin and not currentUserProfile.user.is_superuser:
        return HttpResponseRedirect(reverse(settings.LOGIN_REDIRECT_URL))

    data = dict()
    userProfile = get_object_or_404(models.UserProfile, id=id)
    user = get_object_or_404(models.User, id=userProfile.user.id)
    if request.method == "POST":
        user.delete()
        data['form_is_valid'] = True
        if request.user.is_superuser:
            users = models.UserProfile.objects.all().filter(is_teacher=False).filter(is_admin=False)
        else:
            users = models.UserProfile.objects.all().filter(is_teacher=False).filter(is_admin=False).exclude(user__in=models.User.objects.filter(is_superuser=True))
        data['users_list'] = render_to_string('accounts/admin/userHandle/usersList2.html', {'users': users,
                                                                                            'teacherRequested': teacherRequested,
                                                                                            'adminRequested': adminRequested,
                                                                                            'is_teacher':currentUserProfile.is_teacher,
                                                                                            'is_admin': currentUserProfile.is_admin},
                                              request=request)
    else:
        context = {'user': user, 'teacherRequested': teacherRequested, 'adminRequested': adminRequested,
                   'is_teacher':currentUserProfile.is_teacher, 'is_admin': currentUserProfile.is_admin}
        data['html_form'] = render_to_string('accounts/admin/userHandle/userDelete.html', context, request=request)

    return JsonResponse(data)


class Leaderboard(LoginRequiredMixin, ListView):
    template_name = 'accounts/users/leaderboard.html'
    model = models.UserProfile
    context_object_name = 'users'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        currentUserProfile = models.UserProfile.objects.get(user=self.request.user)
        try:
            teacherRequested = models.TeacherRequest.objects.get(teacherRequest=models.Teacher.objects.get(teacher=currentUserProfile))
            teacherRequested = True
        except ObjectDoesNotExist:
            teacherRequested = False
        try:
            adminRequested = models.AdminRequest.objects.get(adminRequest=models.CustomAdmin.objects.get(admin=currentUserProfile))
            adminRequested = True
        except ObjectDoesNotExist:
            adminRequested = False
        context['userpk'] = currentUserProfile.id
        context['is_teacher'] = currentUserProfile.is_teacher
        context['is_admin'] = currentUserProfile.is_admin
        context['teacherRequested'] = teacherRequested
        context['adminRequested'] = adminRequested
        context['score'] = currentUserProfile.score

        theBest = models.UserProfile.objects.order_by('-score')
        count = 0
        leaderboardPosition = -1

        if theBest[0] == currentUserProfile:
            context['leaderboardPosition'] = 1
        else:
            for i in theBest:
                if i == currentUserProfile:
                    leaderboardPosition = count
                count = count + 1
            context['leaderboardPosition'] = leaderboardPosition + 1
        return context

    def get_queryset(self):
        theBest = models.UserProfile.objects.all().order_by('-score')
        return theBest