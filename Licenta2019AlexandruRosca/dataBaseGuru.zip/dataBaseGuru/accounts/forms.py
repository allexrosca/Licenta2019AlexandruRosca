# https://docs.djangoproject.com/en/2.2/ref/forms/validation/ -> adaptat
# https://docs.djangoproject.com/en/1.8/_modules/django/contrib/auth/forms/ -> adaptat

from django import forms
from django.contrib.auth.models import User
from django.core import validators
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from accounts.models import Teacher, UserProfile, TeacherRequest, CustomAdmin, AdminRequest
from django.contrib.auth import authenticate

class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
    password_conf = forms.CharField(widget=forms.PasswordInput())
    email = forms.EmailField(max_length=250)

    class Meta():
        model = User
        fields = ('username', 'email', 'password')

    def clean_password_conf(self):
        password = self.cleaned_data.get('password')
        password_conf = self.cleaned_data.get('password_conf')
        if password != password_conf:
            raise forms.ValidationError("Password confirmation does not match with your password")
        return password_conf

    def clean_email(self):
        email = self.cleaned_data.get('email')
        eExists = User.objects.filter(email=email)
        if email and eExists.exists():
            raise forms.ValidationError("Email is taken")
        return email

    # https: // docs.djangoproject.com / en / 2.2 / ref / forms / widgets / -> adaptat
    #     +
    # https://stackoverflow.com/questions/48602239/django-authenticate-returns-none-if-registered-via-a-front-end-registration-form -> adaptat
    def __init__(self, *args, **kwargs):
        super(RegisterForm, self).__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({'placeholder': 'Type your username'})
        self.fields['username'].widget.attrs.update({'maxlength': '15'})
        self.fields['email'].widget.attrs.update({'placeholder': 'Your Email (you@something.com)'})
        self.fields['email'].label = 'Email'
        self.fields['password'].widget.attrs.update({'placeholder': 'Type your password'})
        self.fields['password_conf'].widget.attrs.update({'placeholder': 'Confirm your password'})
        self.fields['password_conf'].label = 'Password Confirmation'
    # ---------------------- |~|


# https://stackoverflow.com/questions/15084597/django-error-message-for-login-form -> adaptat
class LoginForm(forms.Form):
    username = forms.CharField(max_length=15, required=True)
    password = forms.CharField(widget=forms.PasswordInput())

    def clean(self):
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')
        user = authenticate(username=username, password=password)
        if not user:
            raise forms.ValidationError("Invalid username or password")
        elif not user.is_active:
            raise forms.ValidationError("Your, account is innactive")

        return self.cleaned_data

    def login(self, request):
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')
        user = authenticate(username=username, password=password)
        return user

    def __init__(self, *args, **kwargs):
        super(LoginForm, self).__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({'placeholder': 'Type your username'})
        self.fields['username'].widget.attrs.update({'maxlength': '15'})
        self.fields['password'].widget.attrs.update({'placeholder': 'Type your password'})
######################################


class UserProfileForm(forms.ModelForm):
    class Meta():
        model = UserProfile
        exclude = ('user',)


class TeacherForm(forms.ModelForm):
    class Meta():
        model = Teacher
        exclude = ('teacher',)

    def __init__(self, *args, **kwargs):
        super(TeacherForm, self).__init__(*args, **kwargs)
        self.fields['teachInstitute'].label = 'Teach Institute'
        self.fields['teachInstitute'].widget.attrs.update({'placeholder': 'Where do you teach? (Institute/ University name)'})
        self.fields['teachInstitute'].widget.attrs.update({'maxlength': '50'})
        self.fields['rank'].widget.attrs.update({"placeholder": "What's your academic rank?"})
        self.fields['rank'].widget.attrs.update({'maxlength': '50'})



class TeacherRequestForm(forms.ModelForm):
    class Meta():
        model = TeacherRequest
        exclude = ('teacherRequest',)

    def __init__(self, *args, **kwargs):
        super(TeacherRequestForm, self).__init__(*args, **kwargs)
        self.fields['reason'].widget.attrs.update({'placeholder': 'Why do you want these rights? (short description)'})
        self.fields['reason'].widget.attrs.update({'maxlength': '100'})
        self.fields['specialty'].widget.attrs.update({"placeholder":"What's your professional specialty?"})
        self.fields['specialty'].widget.attrs.update({'maxlength': '50'})
        self.fields['cv'].label = 'CV'
        self.fields['cv'].widget.attrs.update({"class":"btn btn-outline-grey text-left"})


class AdminForm(forms.ModelForm):
    class Meta():
        model = CustomAdmin
        exclude = ('admin',)

    def __init__(self, *args, **kwargs):
        super(AdminForm, self).__init__(*args, **kwargs)
        self.fields['phoneNumber'].widget.attrs.update({'placeholder': 'Your phone number'})
        self.fields['phoneNumber'].label = 'Phone Number'
        self.fields['programmingLanguages'].widget.attrs.update({'placeholder': 'What are the main programming languages you know?'})
        self.fields['programmingLanguages'].label = 'Programming Languages'
        self.fields['programmingLanguages'].widget.attrs.update({'maxlength': '50'})


class AdminRequestForm(forms.ModelForm):
    class Meta():
        model = AdminRequest
        exclude = ('adminRequest',)

    def __init__(self, *args, **kwargs):
        super(AdminRequestForm, self).__init__(*args, **kwargs)
        self.fields['cv'].label = 'CV'
        self.fields['cv'].widget.attrs.update({"class": "btn btn-outline-grey text-left"})
        self.fields['shortDescription'].label = 'Short Description'
        self.fields['shortDescription'].widget.attrs.update({'placeholder': 'A short description about yourself'})
        self.fields['shortDescription'].widget.attrs.update({'maxlength': '100'})

class ProfilePictureForm(forms.Form):
    image = forms.FileField()