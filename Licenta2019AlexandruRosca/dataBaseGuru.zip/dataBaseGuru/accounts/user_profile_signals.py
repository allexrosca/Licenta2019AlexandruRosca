# https://simpleisbetterthancomplex.com/tutorial/2016/11/23/how-to-add-user-profile-to-django-admin.html -> adaptat
from django.dispatch import receiver
from django.db.models.signals import post_save
from .models import *


@receiver(post_save, sender=User)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        profile = UserProfile(user=instance,
                              firstName='-',
                              lastName='-',
                              age='0',
                              gender='N',
                              qualification='N',
                              city='-',
                              profilePicture='default.jpg',
                              is_teacher=False,
                              is_admin=False,
                              score=0)
        profile.save()

