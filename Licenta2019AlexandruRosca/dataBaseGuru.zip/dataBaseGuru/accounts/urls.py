from django.urls import path
from accounts import views as accounts_views
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static


app_name = 'accounts'

urlpatterns =[
    path('login/', accounts_views.user_login, name='user_login'),
    path('logout/', auth_views.LogoutView.as_view(template_name = 'accounts/users/login.html'), name='user_logout'),
    path('registration/', accounts_views.register, name='user_registration'),
    path('connectedHomePage/', accounts_views.ConnectedHomePageView.as_view(), name='user_connectedHomePage'),
    path('leaderboard/', accounts_views.Leaderboard.as_view(), name='leaderboard'),

    path('userProfile/<int:pk>/', accounts_views.AllUsersProfile.as_view(), name='all_users_profile'),
    path('editProfile/', accounts_views.editProfile, name='edit_profile'),
    path('userProfile/<int:pk>/editProfilePicture/', accounts_views.editProfilePicture, name='edit_profile_picture'),

    path('teacherRightsRequest/', accounts_views.teacherRequest, name='teacher_request'),
    path('adminRightsRequest/', accounts_views.adminRequest, name='admin_request'),

    path('usersList/', accounts_views.UsersListView.as_view(), name='users_list'),
    path('user/<int:id>/delete', accounts_views.user_delete, name='user_delete'),

    path('teachersList/', accounts_views.Teacher_listView.as_view(), name='teachers_list'),
    path('teacher/<int:id>/delete', accounts_views.teacher_delete, name='teacher_delete'),

    path('teacherRequests', accounts_views.TeacherRequest_listView.as_view(), name='teacher_request_list'),
    path('teacherRequests/<int:id>/delete', accounts_views.teacherRequest_delete, name='teacherRequests_delete'),
    path('teacherRequests/<int:id>/accept', accounts_views.teacherRequest_accept, name='teacherRequests_accept'),

    path('adminsList/', accounts_views.AdminsListView.as_view(), name='admins_list'),
    path('admin/<int:id>/delete', accounts_views.admin_delete, name='admin_delete'),

    path('adminRequests/', accounts_views.AdminRequest_listView.as_view(), name='admin_request_list'),
    path('adminRequests/<int:id>/accept', accounts_views.adminRequest_accept, name='adminRequests_accept'),
    path('adminRequests/<int:id>/delete', accounts_views.adminRequest_delete, name='adminRequests_delete'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
