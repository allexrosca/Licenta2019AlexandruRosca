$(document).ready(function(){
    let currentGender = $("#currentGender").text();
    let currentQualif = $("#currentQualif").text();
    console.log(currentGender);
    console.log(currentQualif);
    $("#editProfile").on("click",function(){
        $(".editProfile").addClass("d-none");
        $("#infoContainer").removeClass("justify-content-center");
        $("#infoContainer").addClass("justify-content-around");
        $(".editbtn").removeClass("d-none");
        $(".staticText").addClass("d-none");
        $(".editableText").removeClass("d-none");
        $(".editableTextAux").removeClass("d-none");

//    https://stackoverflow.com/questions/7631360/display-default-as-first-option-in-select-box-without-changing-order
        $("select option[value='"+currentGender[0]+"']").prop("selected",true);
        $("select option[value='"+currentQualif[0]+"']").prop("selected",true);
//    ##########
        }),

    $("#cancelEdit").on("click",function(){
        let pk = $("#editProfile").attr("data-userpk");
        window.location.href = 'http://127.0.0.1:8000/accounts/userProfile/' + pk;
    }),

    $("#acceptEdit").on("click",function(){
        let pk = $("#editProfile").attr("data-userpk");
        $('#lastName').removeAttr("contenteditable");
        $('#lastName').removeClass("editableText");
        $('#firstName').removeAttr("contenteditable");
        $('#firstName').removeClass("editableText");
        $('#age').removeAttr("contenteditable");
        $('#age').removeClass("editableText");
        $('#city').removeAttr("contenteditable");
        $('#city').removeClass("editableText");
        $('#qualif').removeAttr("contenteditable");
        $('#qualif').removeClass("editableText");
        $('#gender').removeAttr("contenteditable");
        $('#gender').removeClass("editableText");
        $('#rank').removeAttr("contenteditable");
        $('#rank').removeClass("editableText");
        $('#teachInstitute').removeAttr("contenteditable");
        $('#teachInstitute').removeClass("editableText");
        let lastName = $("#lastName").text(),
        firstName = $("#firstName").text(),
        age = $("#age").text(),
        city = $("#city").text(),
        rank = $('#rank').text(),
        teachInstitute = $('#teachInstitute').text(),
        gender = $("#gender-option").val(),
        qualification = $("#qualif-option").val();
        $.ajax({
            url: 'http://127.0.0.1:8000/accounts/editProfile/',
            data:{
                'lastName' : lastName,
                'firstName' : firstName,
                'age' : age,
                'city' : city,
                'qualification' : qualification,
                'rank': rank,
                'teachInstitute': teachInstitute,
                'gender': gender,
                'pk': pk
            },
            dataType: 'json'

        });
        window.location.href = 'http://127.0.0.1:8000/accounts/userProfile/' + pk;
    }),


//https://stackoverflow.com/questions/5510129/how-to-disable-paste-ctrlv-with-jquery
    $('.editableText, .editableTextAux').on("cut copy paste",function(e) {
        e.preventDefault();
    }),
//#########################

    //https://stackoverflow.com/questions/44283986/how-to-upload-image-through-jquery
    $('#uploadImg').on('click', function () {
        var file_data = $('#img').prop('files')[0];
        var form_data = new FormData();
        form_data.append('image', file_data);

        form_data.append('csrfmiddlewaretoken', document.getElementsByName('csrfmiddlewaretoken')[0].value);

        $.ajax({
            url: 'editProfilePicture/',
            dataType: 'json',
            data: form_data,
            processData: false,
            contentType: false,
            type: 'POST',
            success: function(e) {
                location.reload()
            }
        });

    });

});
