// https://getbootstrap.com/docs/4.0/components/tooltips/ -> adaptat


// https://github.com/mhadiahmed/CRUD-System?fbclid=IwAR2p07Hq2NHoe-53iP-Olr38oOY1i78dqa9o8U2jKyb8jlbtlvCsRXul_eQ -> preluat si adaptat
// teacher
$(document).ready(function(){
	var ShowForm = function(){
		var btn = $(this);
		$.ajax({
			url: btn.attr("data-url"),
			type: 'get',
			dataType:'json',
			beforeSend: function(){
				$('#modal-req').modal('show');
			},
			success: function(data){
				$('#modal-req .modal-content').html(data.html_form);
			}
		});
	};

	var SaveForm =  function(){
		var form = $(this);
		$.ajax({
			url: form.attr('data-url'),
			data: form.serialize(),
			type: form.attr('method'),
			dataType: 'json',
			success: function(data){
				if(data.form_is_valid){
					$('#req-items').html(data.teacher_request_list);
					$('#modal-req').modal('hide');
				} else {
					$('#modal-req .modal-content').html(data.html_form)
				}
			}
		})
		return false;
	}

$('#req-items').on("click",".show-form-delete",ShowForm);
$('#modal-req').on("submit",".delete-form",SaveForm)
});


//admin
$(document).ready(function(){
	var ShowForm = function(){
		var btn = $(this);
		$.ajax({
			url: btn.attr("admin-url"),
			type: 'get',
			dataType:'json',
			beforeSend: function(){
				$('#modal-adminreq').modal('show');
			},
			success: function(data){
				$('#modal-adminreq .modal-content').html(data.admin_form);
			}
		});
	};

	var SaveForm =  function(){
		var form = $(this);
		$.ajax({
			url: form.attr('admin-url'),
			data: form.serialize(),
			type: form.attr('method'),
			dataType: 'json',
			success: function(data){
				if(data.form_is_valid){
					$('#adminreq-item').html(data.admin_request_list);
					$('#modal-adminreq').modal('hide');
				} else {
					$('#modal-adminreq .modal-content').html(data.admin_form)
				}
			}
		})
		return false;
	}

$('#adminreq-item').on("click",".show-form-delete",ShowForm);
$('#modal-adminreq').on("submit",".delete-form",SaveForm)
});
//#####################################


// https://stackoverflow.com/questions/18517483/displaying-long-text-in-bootstrap-tooltip -> preluat
$("i").tooltip({
	'selector': '',
	'placement': 'bottom',
	'container':'body'
});
//#####################################