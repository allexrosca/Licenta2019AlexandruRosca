# https://faker.readthedocs.io/en/master/ -> adaptat

import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'dataBaseGuru.settings')

import django

django.setup()

import random
from accounts.models import UserProfile, Teacher, CustomAdmin, TeacherRequest, AdminRequest, User
from faker import Faker
import datetime

fake = Faker()


def add_user_account(Nuser=40):
    username = 'user'
    users = []
    for i in range(0, Nuser):
        user = User.objects.get_or_create(username=username + str(i),
                                          email=username + str(i) + '@DBGURU.com',
                                          is_active= True)[0]
        user.set_password('123!@#!@#')
        users.append(user)
        user.save()
    return users


def add_teacher_account(NTeacher=10):
    username = 'teacher'
    users = []
    for i in range(0, NTeacher):
        user = User.objects.get_or_create(username=username + str(i),
                                          email=username + str(i) + '@DBGURU.com',
                                          is_active= True)[0]
        user.set_password('123!@#!@#')
        users.append(user)
        user.save()
    return users


def add_admin_account(NAdmin=10):
    username = 'admin'
    users = []
    for i in range(0, NAdmin):
        user = User.objects.get_or_create(username=username + str(i),
                                          email=username + str(i) + '@DBGURU.com',
                                          is_active= True)[0]
        user.set_password('123!@#!@#')
        users.append(user)
        user.save()
    return users


def add_ta_account(NTA=10):
    username = 'ta'
    users = []
    for i in range(0, NTA):
        user = User.objects.get_or_create(username=username + str(i),
                                          email=username + str(i) + '@DBGURU.com',
                                          is_active= True)[0]
        user.set_password('123!@#!@#')
        users.append(user)
        user.save()
    return users


def populate(Nuser=40, NTeacher=10, NAdmin=10, NTA=10, NTeacherReq=10, NAdminsReq=10):
    userProfileTeacher = []
    userProfileAdmin = []
    userProfileTA = []
    userProfileUsers = []

    print('------------- ADD USERS --------------')
    users = add_user_account(Nuser)
    teachers = add_teacher_account(NTeacher)
    admins = add_admin_account(NAdmin)
    tas = add_ta_account(NTA)
    print('------------- FINISHED ----------------')
    print()


    print('------------- ADD USERPROFILE FOR TEACHERS --------------')
    for i in users:
        userProfileUsers.append(UserProfile.objects.get(user=i))
    print('------------- FINISHED ----------------')
    print()


    print('------------- ADD USERPROFILE FOR TEACHERS --------------')
    for i in teachers:
        teacherUserProfile = UserProfile.objects.get(user=i)
        teacherUserProfile.is_teacher = True
        teacherUserProfile.save()
        userProfileTeacher.append(teacherUserProfile)
    print('------------- FINISHED ----------------')
    print()


    print('------------- ADD USERPROFILE FOR ADMINS --------------')
    for i in admins:
        adminUserProfile = UserProfile.objects.get(user=i)
        adminUserProfile.is_admin = True
        adminUserProfile.save()
        userProfileAdmin.append(adminUserProfile)
    print('------------- FINISHED ----------------')
    print()


    print('------------- ADD USERPROFILE FOR TEACHERS&ADMINS --------------')
    for i in tas:
        adminUserProfile = UserProfile.objects.get(user=i)
        adminUserProfile.is_admin = True
        adminUserProfile.is_teacher = True
        adminUserProfile.save()
        userProfileTA.append(adminUserProfile)
    print('------------- FINISHED ----------------')
    print()


    teacher_rank = ['professor', 'assistant', 'rector', 'dean', 'lecturer', 'associate']
    PLS = ['OOP', 'Operating Systems', 'Mathematics', 'Graphics', 'Alghoritms', 'WEB', 'Artificial Intelligence', 'Statitics', 'Data Base',
           'Java', 'Python', 'Machine Learning', 'DotNet', 'Android']

    print('------------- ADD TEACHERS --------------')
    for i in userProfileTeacher:
        teacher = Teacher.objects.get_or_create(teacher=i,
                                                rank=random.choice(teacher_rank),
                                                teachInstitute=fake.street_name())[0]
        teacher.save()
    print('------------- FINISHED ----------------')
    print()


    print('------------- ADD ADMINS --------------')
    for i in userProfileAdmin:
        admin = CustomAdmin.objects.get_or_create(admin=i,
                                                  phoneNumber=fake.msisdn(),
                                                  programmingLanguages=str(random.choices(PLS, k=random.randint(1, 5)))[1:-1].replace('\'',''))[0]
        admin.save()
    print('------------- FINISHED ----------------')
    print()


    print('------------- ADD TEACHERS&ADMINS --------------')
    for i in userProfileTA:
        teacher = Teacher.objects.get_or_create(teacher=i,
                                                rank=random.choice(teacher_rank),
                                                teachInstitute=fake.street_name())[0]
        teacher.save()

        admin = CustomAdmin.objects.get_or_create(admin=i,
                                                  phoneNumber=fake.msisdn(),
                                                  programmingLanguages=str(random.choices(PLS, k=random.randint(1, 5)))[1:-1].replace('\'',''))[0]
        admin.save()
    print('------------- FINISHED ----------------')
    print()


    teacherReqCount = 0
    adminReqCount = 0
    print('------------- ADD TEACHER AND ADMIN REQUESTS --------------')
    for i in userProfileUsers:
        if teacherReqCount <= NTeacherReq:
            teacher = Teacher.objects.get_or_create(teacher=i,
                                                    rank=random.choice(teacher_rank),
                                                    teachInstitute=fake.street_name())[0]
            teacher.save()

            teacherRequest = TeacherRequest.objects.get_or_create(teacherRequest = teacher,
                                                                  reason=fake.text(max_nb_chars=random.randint(10,100), ext_word_list=None),
                                                                  specialty=random.choice(PLS))[0]
            teacherRequest.save()
            teacherReqCount = teacherReqCount + 1
            continue

        if adminReqCount <= NAdminsReq:
            admin = CustomAdmin.objects.get_or_create(admin=i,
                                                      phoneNumber=fake.msisdn(),
                                                      programmingLanguages=str(random.choices(PLS, k=random.randint(1, 5)))[1:-1].replace('\'', ''))[0]
            admin.save()

            adminRequest = AdminRequest.objects.get_or_create(adminRequest = admin,
                                                              shortDescription=fake.text(max_nb_chars=random.randint(10,100), ext_word_list=None))[0]
            adminRequest.save()
            adminReqCount = adminReqCount + 1
            continue
    print('------------- FINISHED ----------------')
    print()


if __name__ == '__main__':
    print('------------- POPULATION STARTED ----------------')
    print()
    populate()
    print('------------- POPULATION FINISHED ----------------')
